/**
 * workflow-engine.js - 工作流转换与执行引擎
 * 
 * 核心功能:
 * 1. 获取 ComfyUI object_info (节点 widget 定义)
 * 2. 解析 LiteGraph 工作流，提取可编辑 widget
 * 3. LiteGraph → API Prompt 格式转换
 * 4. 提交执行 + 轮询结果
 * 5. 获取输出图像
 */

// ======================================================================
//  object_info 缓存
// ======================================================================
let _objectInfoCache = null;

/**
 * 清除 object_info 缓存（切换 ComfyUI 服务器时调用）
 */
function clearObjectInfoCache() {
    _objectInfoCache = null;
}

/**
 * 获取全量 object_info（节点类型定义）
 */
async function fetchObjectInfo(baseURL) {
    if (_objectInfoCache) return _objectInfoCache;
    
    const resp = await fetch(`${baseURL}/object_info`);
    if (!resp.ok) throw new Error(`获取 object_info 失败: HTTP ${resp.status}`);
    _objectInfoCache = await resp.json();
    return _objectInfoCache;
}

/**
 * 获取指定节点类型的 object_info
 */
function getNodeTypeInfo(classType) {
    if (!_objectInfoCache || !_objectInfoCache[classType]) return null;
    return _objectInfoCache[classType];
}

// ======================================================================
//  Widget 类型判断工具
// ======================================================================

// seed 控制模式值（ComfyUI 前端注入的隐藏 widget，不在 object_info 中）
const SEED_CONTROL_VALUES = new Set(['fixed', 'randomize', 'increment', 'decrement']);

/**
 * 自定义节点对多选枚举的声明名称并不完全统一。
 * ComfyUI 原生 combo 仍是单选，因此只有节点显式声明这些标记时才按数组值处理。
 */
function isMultiSelectConfig(config) {
    if (!config || typeof config !== 'object') return false;
    const flags = ['multi_select', 'multiselect', 'multiSelect', 'multiple', 'allow_multiple', 'allowMultiple', 'is_multi_select', 'isMultiSelect'];
    for (const key of flags) {
        if (config[key] === true) return true;
    }
    const mode = config.selection_mode ?? config.selectionMode ?? config.mode;
    if (typeof mode === 'string' && /multi|multiple/i.test(mode)) return true;
    return Array.isArray(config.default);
}

/**
 * 判断是否是 seed 类型的 INT（max 值极大）
 */
function isSeedLikeInt(inputName, inputDef) {
    if (!Array.isArray(inputDef) || inputDef.length < 2) return false;
    const type = inputDef[0];
    if (typeof type !== 'string' || type.toUpperCase() !== 'INT') return false;
    const config = inputDef[1] || {};
    // seed/noise_seed 名称匹配，或 max 值 > 2^48
    return inputName.toLowerCase().includes('seed') || (config.max && config.max > 281474976710656);
}

/**
 * 判断 object_info 中的 input 定义是什么类型的 widget
 * 返回: { widgetType, config }
 *   widgetType: 'INT' | 'FLOAT' | 'STRING' | 'COMBO' | 'BOOL' | 'CONNECTED' (连接输入,非widget)
 */
function classifyInput(inputDef) {
    if (!Array.isArray(inputDef) || inputDef.length === 0) {
        return { widgetType: 'CONNECTED', config: {} };
    }

    const firstElement = inputDef[0];
    
    // Combo/dropdown: [["option1", "option2", ...]]
    if (Array.isArray(firstElement)) {
        const comboConfig = Object.assign({}, (inputDef.length > 1 && inputDef[1]) || {}, { options: firstElement });
        comboConfig.multiple = isMultiSelectConfig(comboConfig);
        return { widgetType: 'COMBO', config: comboConfig };
    }
    
    // 类型字符串
    if (typeof firstElement === 'string') {
        const typeStr = firstElement.toUpperCase();
        const config = inputDef.length > 1 ? inputDef[1] : {};
        
        switch (typeStr) {
            case 'INT':
                return { widgetType: 'INT', config: {
                    default: config.default ?? 0,
                    min: config.min ?? 0,
                    max: config.max ?? 99999999,
                    step: config.step ?? 1,
                }};
            case 'FLOAT':
                return { widgetType: 'FLOAT', config: {
                    default: config.default ?? 0.0,
                    min: config.min ?? 0.0,
                    max: config.max ?? 100.0,
                    step: config.step ?? 0.01,
                    round: config.round ?? 0.001,
                }};
            case 'STRING':
                const stringConfig = {
                    default: config.default ?? '',
                    multiline: config.multiline ?? false,
                    placeholder: config.placeholder ?? '',
                    options: Array.isArray(config.options) ? config.options : (Array.isArray(config.values) ? config.values : undefined),
                    labels: Array.isArray(config.labels) ? config.labels : undefined,
                };
                stringConfig.multiple = isMultiSelectConfig(config);
                return { widgetType: 'STRING', config: stringConfig };
            case 'COMBO':
                const comboOptions = Array.isArray(config.options) ? config.options : (Array.isArray(config.values) ? config.values : []);
                const comboConfig = Object.assign({}, config, { options: comboOptions });
                comboConfig.multiple = isMultiSelectConfig(config);
                return { widgetType: 'COMBO', config: comboConfig };
            case 'BOOLEAN':
                return { widgetType: 'BOOL', config: {
                    default: config.default ?? false,
                }};
            default:
                // MODEL, CONDITIONING, LATENT, IMAGE 等 → 连接输入
                return { widgetType: 'CONNECTED', config: {}, typeName: typeStr };
        }
    }
    
    return { widgetType: 'CONNECTED', config: {} };
}

// ======================================================================
//  工作流解析：提取可编辑 widgets
// ======================================================================

/**
 * 从 LiteGraph 工作流解析出每个节点的可编辑 widgets
 * 
 * @param {Object} workflow - LiteGraph 格式工作流 { nodes, links, ... }
 * @param {Object} objectInfo - ComfyUI object_info
 * @returns {Array} 节点数组，每个节点包含 { nodeId, title, type, widgets[] }
 *   widget: { name, widgetType, config, value, inputIndex }
 */
function parseWorkflowWidgets(workflow, objectInfo) {
    // ComfyUI API 格式: {"3": {class_type, inputs:{...}}}。
    // 这类工作流没有 LiteGraph nodes/widgets_values，仍需把普通输入暴露到参数区。
    if (!workflow.nodes) {
        const apiResult = [];
        Object.keys(workflow || {}).forEach(nodeId => {
            const node = workflow[nodeId];
            if (!node || !node.inputs || !node.class_type) return;
            if (/^Primitive(?:String|Int|Float|Bool|Boolean|Node)$/i.test(node.class_type) || node.class_type === 'Reroute' || node.class_type === 'Note') return;
            const widgets = [];
            const info = objectInfo && objectInfo[node.class_type];
            const defs = {};
            if (info && info.input) {
                Object.assign(defs, info.input.required || {}, info.input.optional || {});
            }
            Object.keys(node.inputs).forEach(name => {
                const value = node.inputs[name];
                // 连接引用 [nodeId, slot] 不是可编辑 widget。
                const connected = Array.isArray(value) && value.length === 2 && (typeof value[0] === 'string' || typeof value[0] === 'number');
                const classified = defs[name] ? classifyInput(defs[name]) : null;
                if (connected) {
                    // API Prompt 没有 LiteGraph link 元数据，但仍要按 SD-PPP 规则显示
                    // 连接输入，让用户知道模型/图像/条件来自哪个工作流端口；该控件只读，
                    // 提交时保留原始连接引用。
                    widgets.push({
                        name,
                        widgetType: classified && classified.widgetType === 'CONNECTED' ? 'CONNECTED' : 'CONNECTED',
                        config: { typeName: classified && classified.typeName ? classified.typeName : 'CONNECTED' },
                        value: '已连接',
                        isConnected: true,
                        isImageInput: false,
                    });
                    return;
                }
                let widgetType = classified ? classified.widgetType : 'STRING';
                if (widgetType === 'CONNECTED') {
                    // API 工作流里没有 LiteGraph link 元数据；已有的标量值仍可作为入口编辑。
                    widgetType = typeof value === 'boolean' ? 'BOOL' : (typeof value === 'number' ? (Number.isInteger(value) ? 'INT' : 'FLOAT') : 'STRING');
                }
                const config = classified ? classified.config : {};
                widgets.push({ name, widgetType, config, value, isConnected: false, isImageInput: (node.class_type === 'LoadImage' || node.class_type === 'LoadImageMask' || node.class_type === 'PS Bridge Load Image' || node.class_type === 'PS Bridge Load Image Mask') && name === 'image' });
            });
            if ((node.class_type === 'LoadImage' || node.class_type === 'LoadImageMask' || node.class_type === 'PS Bridge Load Image' || node.class_type === 'PS Bridge Load Image Mask') && !widgets.some(w => w.name === 'image')) {
                widgets.unshift({ name: 'image', widgetType: 'STRING', config: {}, value: '', isConnected: false, isImageInput: true });
            }
            if (widgets.length) apiResult.push({ nodeId, title: node._meta && node._meta.title ? node._meta.title : (node.title || node.class_type), type: node.class_type, widgets, connectedInputs: {} });
        });
        return apiResult;
    }
    
    const result = [];
    
    // 构建 link 映射：link_id → { sourceNodeId, sourceSlot }
    const linkMap = {};
    if (workflow.links) {
        workflow.links.forEach(link => {
            // link 格式: [link_id, source_node_id, source_slot, target_node_id, target_slot, type]
            linkMap[link[0]] = {
                sourceNodeId: link[1],
                sourceSlot: link[2],
                targetNodeId: link[3],
                targetSlot: link[4],
                type: link[5],
            };
        });
    }
    
    workflow.nodes.forEach(node => {
        const classType = node.type;
        if (/^Primitive(?:String|Int|Float|Bool|Boolean|Node)$/i.test(classType) || classType === 'Reroute' || classType === 'Note') return;
        const nodeInfo = objectInfo && objectInfo[classType];
        
        if (!nodeInfo || !nodeInfo.input) {
            // 未知节点类型：使用 fallback 从 widgets_values + node.widgets 提取
            const fallbackEntry = {
                nodeId: node.id,
                title: node.title || (node.properties && node.properties.title) || (node._meta && node._meta.title) || classType,
                type: classType,
                widgets: [],
                connectedInputs: {},
                _isUnknown: true,
            };
            const connectedNames = new Set();
            if (node.inputs) {
                node.inputs.forEach(inp => {
                    if (inp.link !== null && inp.link !== undefined) {
                        connectedNames.add(inp.name);
                    }
                });
            }
            // 尝试从 LiteGraph node.widgets 元数据提取
            if (node.widgets_values) {
                if (node.widgets && node.widgets.length > 0) {
                    node.widgets.forEach((w, idx) => {
                        if (!w || !w.name) return;
                        const val = idx < node.widgets_values.length ? node.widgets_values[idx] : undefined;
                        const isConn = connectedNames.has(w.name);
                        // 推断 widgetType
                        let wType = 'STRING';
                        if (typeof val === 'number') wType = Number.isInteger(val) ? 'INT' : 'FLOAT';
                        else if (typeof val === 'boolean') wType = 'BOOL';
                        else if (w.type === 'combo' || (w.options && w.options.values)) wType = 'COMBO';
                        const widgetConfig = wType === 'COMBO' ? {
                            options: (w.options && w.options.values) || [],
                            multiple: isMultiSelectConfig(w.options || {})
                        } : {};
                        fallbackEntry.widgets.push({
                            name: w.name,
                            widgetType: wType,
                            config: widgetConfig,
                            value: val,
                            isConnected: isConn,
                        });
                    });
                } else {
                    // 没有 node.widgets 元数据，用索引作为名称
                    node.widgets_values.forEach((val, idx) => {
                        if (val === undefined || val === null) return;
                        let wType = 'STRING';
                        if (typeof val === 'number') wType = Number.isInteger(val) ? 'INT' : 'FLOAT';
                        else if (typeof val === 'boolean') wType = 'BOOL';
                        fallbackEntry.widgets.push({
                            name: 'param_' + idx,
                            widgetType: wType,
                            config: {},
                            value: val,
                            isConnected: false,
                        });
                    });
                }
            }
            if (fallbackEntry.widgets.length > 0) {
                result.push(fallbackEntry);
            }
            return;
        }
        
        const nodeEntry = {
            nodeId: node.id,
            title: node.title || (node.properties && node.properties.title) || (node._meta && node._meta.title) || classType,
            type: classType,
            widgets: [],
            // 保存连接信息
            connectedInputs: {},
        };
        
        // 获取已连接的输入名称集合
        // node.inputs[] 中有 link 值的表示已连接
        const connectedInputNames = new Set();
        if (node.inputs) {
            node.inputs.forEach(inp => {
                if (inp.link !== null && inp.link !== undefined) {
                    connectedInputNames.add(inp.name);
                    nodeEntry.connectedInputs[inp.name] = linkMap[inp.link] || null;
                }
            });
        }
        
        // 按 required → optional 顺序遍历 inputs
        // widgets_values 数组的顺序对应非连接 widget 的定义顺序
        let widgetValueIndex = 0;
        const widgetValues = node.widgets_values || [];
        
        const allInputs = {};
        if (nodeInfo.input.required) Object.assign(allInputs, nodeInfo.input.required);
        if (nodeInfo.input.optional) Object.assign(allInputs, nodeInfo.input.optional);
        
        // 遍历 object_info 中定义的输入
        for (const [inputName, inputDef] of Object.entries(allInputs)) {
            const { widgetType, config, typeName } = classifyInput(inputDef);
            
            if (widgetType === 'CONNECTED') {
                // 这是连接类型（MODEL, IMAGE 等），不是 widget
                // 但如果它也出现在 widgets_values 中（某些节点同时支持连接和widget），
                // 这种情况在 ComfyUI 中存在但罕见
                if (connectedInputNames.has(inputName)) {
                    nodeEntry.widgets.push({
                        name: inputName,
                        widgetType: 'CONNECTED',
                        config: { typeName: typeName || 'CONNECTED' },
                        value: '已连接',
                        isConnected: true,
                        isImageInput: false,
                    });
                }
                continue;
            }
            
            // 如果这个输入已经有连接，它在 widgets_values 中可能仍然有一个占位值
            // ComfyUI LiteGraph 在连接时通常会跳过 widget value，但有时会保留
            // 我们需要正确追踪 widgetValueIndex
            
            const isConnected = connectedInputNames.has(inputName);
            
            // 获取当前 widget 的值
            let currentValue = config.default;
            if (widgetValueIndex < widgetValues.length) {
                currentValue = widgetValues[widgetValueIndex];
            }
            widgetValueIndex++;
            
            // 已连接的输入不显示为可编辑 widget（但保留在数据中）
            nodeEntry.widgets.push({
                name: inputName,
                widgetType: widgetType,
                config: config,
                value: currentValue,
                isConnected: isConnected,
            });

            // ComfyUI 会在 seed 后追加一个未出现在 object_info 的控制 widget。
            // 暴露它，才能在参数区选择 fixed/randomize/increment/decrement。
            if (isSeedLikeInt(inputName, inputDef) &&
                widgetValueIndex < widgetValues.length &&
                typeof widgetValues[widgetValueIndex] === 'string' &&
                SEED_CONTROL_VALUES.has(widgetValues[widgetValueIndex])) {
                nodeEntry.widgets.push({
                    name: 'control_after_generate',
                    widgetType: 'COMBO',
                    config: { options: Array.from(SEED_CONTROL_VALUES) },
                    value: widgetValues[widgetValueIndex],
                    isConnected: false,
                });
                widgetValueIndex++;
            }
        }

        // LoadImage 的 image 输入在部分版本中被 object_info 标成 IMAGE 连接类型，
        // 但它仍是用户需要在面板中选择/替换的工作流入口。
        if ((classType === 'LoadImage' || classType === 'LoadImageMask' || classType === 'PS Bridge Load Image' || classType === 'PS Bridge Load Image Mask') &&
            !nodeEntry.widgets.some(w => w.name === 'image')) {
            nodeEntry.widgets.unshift({ name: 'image', widgetType: 'STRING', config: { multiline: false }, value: '', isConnected: false, isImageInput: true });
        }
        
        // 添加所有有 widget 的节点（包括已连接的，前端显示为只读）
        if (nodeEntry.widgets.length > 0) {
            result.push(nodeEntry);
        }
    });
    
    return result;
}

// ======================================================================
//  LiteGraph → API Prompt 转换
// ======================================================================

/**
 * 将 LiteGraph 工作流 + 用户编辑的参数 转换为 ComfyUI API Prompt 格式
 * 
 * @param {Object} workflow - LiteGraph 工作流
 * @param {Object} objectInfo - ComfyUI object_info
 * @param {Object} editedValues - 用户编辑的值 { "nodeId.widgetName": value }
 * @returns {Object} API prompt { "nodeId": { class_type, inputs: {...} } }
 */
// 前端专用虚拟节点类型（不应出现在 API prompt 中）
const FRONTEND_ONLY_NODES = new Set(['PrimitiveNode', 'PrimitiveString', 'PrimitiveInt', 'PrimitiveFloat', 'PrimitiveBool', 'PrimitiveBoolean', 'Reroute', 'Note']);

function isPrimitiveNodeType(type) {
    return /^Primitive(?:String|Int|Float|Bool|Boolean|Node)$/i.test(String(type || ''));
}

// Some ComfyUI frontend versions serialize the LoadImage widget as a tuple,
// but the API expects only the uploaded filename string.
function normalizeLoadImageInputs(prompt) {
    Object.keys(prompt || {}).forEach(function(nodeId) {
        const node = prompt[nodeId];
        if (!node || (node.class_type !== 'LoadImage' && node.class_type !== 'LoadImageMask') || !node.inputs) return;

        let image = node.inputs.image;
        while (Array.isArray(image) && image.length > 0) image = image[0];
        if (typeof image === 'string') node.inputs.image = image;
    });
}

function convertToAPIPrompt(workflow, objectInfo, editedValues = {}) {
    // API prompt 格式无需重新按 widgets_values 对齐，直接克隆并应用编辑值。
    if (!workflow.nodes) {
        const apiPrompt = {};
        Object.keys(workflow || {}).forEach(nodeId => {
            const node = workflow[nodeId];
            if (!node || !node.class_type) return;
            const inputs = Object.assign({}, node.inputs || {});
            Object.keys(inputs).forEach(name => {
                const key = String(nodeId) + '.' + name;
                if (!Object.prototype.hasOwnProperty.call(editedValues, key)) return;
                let value = editedValues[key];
                const original = inputs[name];
                if (typeof original === 'number') value = Number(value);
                else if (typeof original === 'boolean') value = value === true || String(value).toLowerCase() === 'true';
                inputs[name] = value;
            });
            apiPrompt[String(nodeId)] = { class_type: node.class_type, inputs };
        });
        if (Object.keys(apiPrompt).length) {
            normalizeLoadImageInputs(apiPrompt);
            return apiPrompt;
        }
        throw new Error('工作流格式不正确');
    }
    
    const prompt = {};
    
    // 构建 link 映射
    const linkMap = {};
    if (workflow.links) {
        workflow.links.forEach(link => {
            linkMap[link[0]] = {
                sourceNodeId: link[1],
                sourceSlot: link[2],
            };
        });
    }
    
    // 构建节点 ID → 节点对象映射
    const nodeById = {};
    workflow.nodes.forEach(n => { nodeById[n.id] = n; });
    
    /**
     * 解析 PrimitiveNode/Reroute 的实际值
     * PrimitiveNode: 优先使用 editedValues，否则返回 widgets_values[0]（常量值）
     * Reroute: 追溯上游连接，直到找到非 Reroute 节点
     */
    function resolvePrimitiveValue(nodeId) {
        const node = nodeById[nodeId];
        if (!node) return undefined;
        
        if (isPrimitiveNodeType(node.type)) {
            const nid = String(nodeId);
            const origVal = node.widgets_values && node.widgets_values.length > 0 ? node.widgets_values[0] : undefined;
            
            // 检查 editedValues：PrimitiveNode 在 fallback 解析中可能使用 param_0 或实际 widget 名
            // 尝试所有可能的 key
            let editedVal = undefined;
            let found = false;
            
            // 1. 尝试 param_0（fallback 解析时无 node.widgets 元数据的情况）
            if (editedValues.hasOwnProperty(nid + '.param_0')) {
                editedVal = editedValues[nid + '.param_0'];
                found = true;
            }
            // 2. 尝试实际 widget 名（有 node.widgets 元数据的情况）
            if (!found && node.widgets && node.widgets[0] && node.widgets[0].name) {
                const wName = node.widgets[0].name;
                if (editedValues.hasOwnProperty(nid + '.' + wName)) {
                    editedVal = editedValues[nid + '.' + wName];
                    found = true;
                }
            }
            // 3. 通用搜索：找到第一个匹配 nodeId.* 的 key（排除 control_after_generate）
            if (!found) {
                for (const key of Object.keys(editedValues)) {
                    if (key.startsWith(nid + '.') && !key.endsWith('.param_1')) {
                        editedVal = editedValues[key];
                        found = true;
                        break;
                    }
                }
            }
            
            if (found && editedVal !== undefined) {
                // 类型转换：根据原始值类型推断
                if (typeof origVal === 'number') {
                    if (Number.isInteger(origVal)) {
                        editedVal = parseInt(editedVal);
                        if (isNaN(editedVal)) editedVal = origVal;
                    } else {
                        editedVal = parseFloat(editedVal);
                        if (isNaN(editedVal)) editedVal = origVal;
                    }
                } else if (typeof origVal === 'boolean') {
                    editedVal = (editedVal === 'true' || editedVal === true);
                }
                return editedVal;
            }
            
            return origVal;
        }
        
        if (node.type === 'Reroute') {
            // Reroute 追溯上游
            if (node.inputs && node.inputs[0] && node.inputs[0].link != null) {
                const upstreamLink = linkMap[node.inputs[0].link];
                if (upstreamLink) {
                    const upNode = nodeById[upstreamLink.sourceNodeId];
                    if (upNode && FRONTEND_ONLY_NODES.has(upNode.type)) {
                        return resolvePrimitiveValue(upstreamLink.sourceNodeId);
                    }
                    // 非虚拟节点 → 返回连接引用
                    return [String(upstreamLink.sourceNodeId), upstreamLink.sourceSlot];
                }
            }
            return undefined;
        }
        
        return undefined; // 不是虚拟节点
    }
    
    /**
     * 解析连接引用：如果连接的源节点是虚拟节点，内联其值
     */
    function resolveConnection(sourceNodeId, sourceSlot) {
        const sourceNode = nodeById[sourceNodeId];
        if (!sourceNode) return [String(sourceNodeId), sourceSlot];
        
        if (isPrimitiveNodeType(sourceNode.type)) {
            return resolvePrimitiveValue(sourceNodeId);
        }
        
        if (sourceNode.type === 'Reroute') {
            const resolved = resolvePrimitiveValue(sourceNodeId);
            if (resolved !== undefined) return resolved;
        }
        
        // 普通节点 → 保持连接引用
        return [String(sourceNodeId), sourceSlot];
    }
    
    const _skippedNodes = [];
    
    workflow.nodes.forEach(node => {
        // 跳过前端专用虚拟节点
        if (FRONTEND_ONLY_NODES.has(node.type)) {
            return;
        }
        
        const classType = node.type;
        const nodeInfo = objectInfo[classType];
        const nodeId = String(node.id);
        const inputs = {};
        
        // 构建连接输入（无论是否有 object_info 都需要）
        
        // 获取已连接的输入（解析虚拟节点引用）
        const connectedInputs = {};
        if (node.inputs) {
            node.inputs.forEach((inp, slotIndex) => {
                if (inp.link !== null && inp.link !== undefined) {
                    const linkInfo = linkMap[inp.link];
                    if (linkInfo) {
                        // 解析 PrimitiveNode/Reroute → 内联值
                        connectedInputs[inp.name] = resolveConnection(linkInfo.sourceNodeId, linkInfo.sourceSlot);
                    }
                }
            });
        }
        
        // 未知节点类型：使用 fallback（连接 + 原始 widget 值）
        if (!nodeInfo || !nodeInfo.input) {
            // 添加所有连接（已解析虚拟节点）
            Object.assign(inputs, connectedInputs);
            
            // 尝试从 node.widgets 和 widgets_values 提取原始值
            if (node.widgets_values && node.widgets) {
                node.widgets.forEach((w, idx) => {
                    if (w && w.name && !Object.prototype.hasOwnProperty.call(connectedInputs, w.name)) {
                        const val = idx < node.widgets_values.length ? node.widgets_values[idx] : undefined;
                        if (val !== undefined) inputs[w.name] = val;
                    }
                });
            }
            
            _skippedNodes.push(`[${nodeId}] ${classType} (未知节点，使用 fallback)`);
            prompt[nodeId] = { class_type: classType, inputs: inputs };
            return; // 继续下一个节点
        }
        
        // 遍历 object_info 的输入定义
        const allInputDefs = {};
        if (nodeInfo.input.required) Object.assign(allInputDefs, nodeInfo.input.required);
        if (nodeInfo.input.optional) Object.assign(allInputDefs, nodeInfo.input.optional);
        
        let widgetValueIndex = 0;
        const widgetValues = node.widgets_values || [];
        
        for (const [inputName, inputDef] of Object.entries(allInputDefs)) {
            const { widgetType } = classifyInput(inputDef);
            
            if (widgetType === 'CONNECTED') {
                // 类型是 MODEL/IMAGE 等 → 不是 widget，不占 widgets_values 位置
                // 如果有连接，设置连接引用
                if (Object.prototype.hasOwnProperty.call(connectedInputs, inputName)) {
                    inputs[inputName] = connectedInputs[inputName];
                } else if ((classType === 'LoadImage' || classType === 'LoadImageMask' || classType === 'PS Bridge Load Image' || classType === 'PS Bridge Load Image Mask') &&
                           Object.prototype.hasOwnProperty.call(editedValues, `${nodeId}.${inputName}`)) {
                    inputs[inputName] = editedValues[`${nodeId}.${inputName}`];
                }
                continue;
            }
            
            // 以下是 widget 类型（INT/FLOAT/STRING/COMBO/BOOL）
            // 即使被连接，也要消耗 widgetValueIndex（LiteGraph 中仍保留值）
            
            // 如果有连接，使用连接引用，但仍然递增 index
            if (Object.prototype.hasOwnProperty.call(connectedInputs, inputName)) {
                const connectedEditKey = `${nodeId}.${inputName}`;
                // LoadImage 等入口允许面板直接替换文件名；其它连接输入继续保持连接引用。
                if ((classType === 'LoadImage' || classType === 'LoadImageMask' || classType === 'PS Bridge Load Image' || classType === 'PS Bridge Load Image Mask') &&
                    Object.prototype.hasOwnProperty.call(editedValues, connectedEditKey)) {
                    inputs[inputName] = editedValues[connectedEditKey];
                } else {
                    inputs[inputName] = connectedInputs[inputName];
                }
                widgetValueIndex++;
                continue;
            }
            
            // Widget 输入：优先使用用户编辑的值
            const editKey = `${nodeId}.${inputName}`;
            let value;
            
            if (editedValues.hasOwnProperty(editKey)) {
                value = editedValues[editKey];
                // 类型转换
                if (widgetType === 'INT') value = parseInt(value) || 0;
                else if (widgetType === 'FLOAT') value = parseFloat(value) || 0.0;
                else if (widgetType === 'BOOL') {
                    value = (typeof value === 'string')
                        ? value.trim().toLowerCase() === 'true'
                        : !!value;
                }
            } else {
                // 使用工作流中的原始值
                value = widgetValueIndex < widgetValues.length ? widgetValues[widgetValueIndex] : undefined;
            }
            
            if (value !== undefined) {
                // ComfyUI 前端的 seed 控制 widget 不会出现在 API prompt 中。
                // SD-PPP 提交时把它折算成实际 seed，确保 randomize/increment/decrement
                // 在插件内执行也能得到与原工作流一致的结果。
                if (isSeedLikeInt(inputName, inputDef)) {
                    const controlKey = `${nodeId}.control_after_generate`;
                    const control = editedValues[controlKey];
                    if (control === 'randomize') {
                        const maxSeed = (inputDef[1] && Number.isFinite(inputDef[1].max)) ? inputDef[1].max : 0x7fffffff;
                        value = Math.floor(Math.random() * Math.max(1, maxSeed));
                    } else if (control === 'increment') {
                        value = Number(value) + 1;
                    } else if (control === 'decrement') {
                        value = Math.max(0, Number(value) - 1);
                    }
                }
                inputs[inputName] = value;
            }
            
            widgetValueIndex++;

            // control_after_generate 是前端控制值，不属于 API prompt 输入；
            // 但它仍占用 LiteGraph 的 widgets_values 槽位。
            if (isSeedLikeInt(inputName, inputDef) &&
                widgetValueIndex < widgetValues.length &&
                typeof widgetValues[widgetValueIndex] === 'string' &&
                SEED_CONTROL_VALUES.has(widgetValues[widgetValueIndex])) {
                widgetValueIndex++;
            }
        }
        
        prompt[nodeId] = {
            class_type: classType,
            inputs: inputs,
        };
    });
    
    normalizeLoadImageInputs(prompt);
    return prompt;
}

// ======================================================================
//  执行工作流
// ======================================================================

/**
 * 提交工作流到 ComfyUI 执行
 * @returns {string} prompt_id
 */
async function submitPrompt(baseURL, prompt) {
    const resp = await fetch(`${baseURL}/prompt`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt: prompt }),
    });
    
    if (!resp.ok) {
        const text = await resp.text();
        // 解析节点错误详情
        try {
            const errData = JSON.parse(text);
            if (errData.node_errors) {
                const errNodes = Object.entries(errData.node_errors).map(([id, info]) => {
                    const msgs = (info.errors || []).map(e => e.message + ': ' + e.details).join('; ');
                    return `[${id}] ${info.class_type}: ${msgs}`;
                });
                throw new Error(`节点验证失败:\n${errNodes.join('\n')}`);
            }
        } catch (parseErr) {
            if (parseErr.message.includes('节点验证失败')) throw parseErr;
        }
        throw new Error(`提交失败 HTTP ${resp.status}: ${text}`);
    }
    
    const result = await resp.json();
    // 检查是否有节点警告
    if (result.node_errors && Object.keys(result.node_errors).length > 0) {
        const warnNodes = Object.keys(result.node_errors);
        console.warn(`[PS Bridge] 部分节点有警告: ${warnNodes.join(', ')}`);
    }
    return result.prompt_id;
}

/**
 * 轮询检查任务是否完成
 * @returns {Object} history entry for the prompt
 */
async function pollForCompletion(baseURL, promptId, onProgress, timeoutMs = 3600000) {
    const startTime = Date.now();
    const pollInterval = 1000;
    
    while (Date.now() - startTime < timeoutMs) {
        try {
            const resp = await fetch(`${baseURL}/history/${promptId}`);
            if (resp.ok) {
                const history = await resp.json();
                if (history[promptId]) {
                    const entry = history[promptId];
                    if (entry.status && entry.status.completed) {
                        return entry;
                    }
                    if (entry.status && entry.status.status_str === 'error') {
                        throw new Error('ComfyUI 执行出错: ' + JSON.stringify(entry.status));
                    }
                }
            }
        } catch (e) {
            if (e.message.includes('执行出错')) throw e;
            // 其他错误（网络问题）继续重试
        }
        
        if (onProgress) {
            const elapsed = (Date.now() - startTime) / 1000;
            onProgress(`执行中... ${elapsed.toFixed(0)}s`);
        }
        
        // 等待
        await new Promise(resolve => setTimeout(resolve, pollInterval));
    }
    
    throw new Error(`执行超时 (${timeoutMs/1000}s)`);
}

/**
 * 从 history 中提取输出图像信息
 * @returns {Array} [{ filename, subfolder, type }]
 */
function extractOutputImages(historyEntry) {
    const images = [];
    if (!historyEntry.outputs) return images;
    
    for (const [nodeId, output] of Object.entries(historyEntry.outputs)) {
        if (output.images) {
            output.images.forEach(img => {
                images.push({
                    filename: img.filename,
                    subfolder: img.subfolder || '',
                    type: img.type || 'output',
                    nodeId: nodeId,
                });
            });
        }
    }
    
    return images;
}

/**
 * 下载图像数据
 * @returns {ArrayBuffer} 图像二进制数据
 */
async function downloadImage(baseURL, imageInfo) {
    const params = new URLSearchParams({
        filename: imageInfo.filename,
        subfolder: imageInfo.subfolder,
        type: imageInfo.type,
    });
    
    const resp = await fetch(`${baseURL}/view?${params}`);
    if (!resp.ok) throw new Error(`下载图像失败: HTTP ${resp.status}`);
    
    return await resp.arrayBuffer();
}

/**
 * 上传图像到 ComfyUI
 * @returns {Object} { name, subfolder, type }
 */
async function uploadImage(baseURL, pngArrayBuffer, filename) {
    const formData = new FormData();
    const blob = new Blob([pngArrayBuffer], { type: 'image/png' });
    formData.append('image', blob, filename || 'ps_canvas.png');
    formData.append('overwrite', 'true');
    
    const resp = await fetch(`${baseURL}/upload/image`, {
        method: 'POST',
        body: formData,
    });
    
    if (!resp.ok) throw new Error(`上传图像失败: HTTP ${resp.status}`);
    
    return await resp.json();
}

// ======================================================================
//  导出
// ======================================================================
module.exports = {
    fetchObjectInfo,
    clearObjectInfoCache,
    getNodeTypeInfo,
    classifyInput,
    isMultiSelectConfig,
    parseWorkflowWidgets,
    convertToAPIPrompt,
    normalizeLoadImageInputs,
    submitPrompt,
    pollForCompletion,
    extractOutputImages,
    downloadImage,
    uploadImage,
};
