// ============================================================
//  tile-comfyui.js - ComfyUI 工作流磁贴
//  连接 ComfyUI 服务器，加载工作流，动态渲染参数，执行生成
// ============================================================
(function() {
'use strict';

// ========== 私有状态 ==========
var _activeContainer = null;
var _comfyConnecting = false;
var _comfyAutoConnectDone = false;

function _esc(s) {
  return String(s || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

function _getUrl() {
  return (TileAPI.state.get('comfyui.url') || 'http://127.0.0.1:8188').replace(/\/$/, '');
}

// ========== 磁贴注册 ==========

TileAPI.registerTile({
  id: 'comfyui',
  group: 'main',
  icon: '\uD83C\uDFAF',
  label: 'ComfyUI',
  desc: 'ComfyUI \u5DE5\u4F5C\u6D41',
  live: false,
  defaultSize: { w: 2, h: 2 },
  minSize: { w: 1, h: 1 },
  maxSize: { w: 4, h: 999 },   // 纵向不限高: 999 行 ≈ 无限 (纵向网格可无限延伸)

  onExpand: function(container, sizeHint) {
    var layout = (sizeHint && sizeHint.layout) || 'wide';

    // 窄/高布局一律用 square 渲染(单列竖排,内容全),避免 URL 框变成 hidden 改不了
    if (layout === 'narrow' || layout === 'tall') layout = 'square';
    // (上一行已把 narrow/tall 归一成 square, 故不再有单独的 narrow 分支 —— 原来那个分支永远走不到)
    if (layout === 'wideshort') {
      _renderWideShort(container);
    } else if (layout === 'square') {
      _renderSquare(container);
    } else {
      _renderWide(container);
    }

    _activeContainer = container;
    _ensureWorkflowSelect(container);
    _ensureGallery(container);
    _bindCoreEvents(container);
    _loadSavedValues(container);
    _renderComfyTopImageButtons(container);

    // 自动连接
    var savedUrl = TileAPI.storage.get('comfyui.url');
    if (savedUrl && !_comfyAutoConnectDone) {
      _comfyAutoConnectDone = true;
      TileAPI.state.set('comfyui.url', savedUrl);
      var urlInp = container.querySelector('#comfyUrl');
      if (urlInp) urlInp.value = savedUrl;
      _comfyConnecting = true;
      var statusEl = container.querySelector('#comfyStatus');
      if (statusEl) { statusEl.textContent = '\u8FDE\u63A5\u4E2D...'; statusEl.style.color = 'var(--text-sub)'; }
      TileAPI.sendToHost('comfyConnect', { url: savedUrl.replace(/\/$/, ''), silent: true });
    }

    return function() { _activeContainer = null; };
  },

  onMessage: function(action, data) {
    _handleHostMessage(action, data);
  },

  onStorageLoaded: function(storage) {
    var url = storage.get('comfyui.url');
    if (url) TileAPI.state.set('comfyui.url', url);
    // state 只在当前面板会话内存在；工作流自定义排序需要从持久化存储恢复。
    var savedOrder = storage.get('comfyui.keyNodeOrder');
    if (savedOrder && typeof savedOrder === 'object' && !Array.isArray(savedOrder)) {
      TileAPI.state.set('comfyui.keyNodeOrder', savedOrder);
    }
    var savedNodeState = storage.get('comfyui.nodeEnabledByWorkflow');
    if (savedNodeState && typeof savedNodeState === 'object' && !Array.isArray(savedNodeState)) {
      TileAPI.state.set('comfyui.nodeEnabledByWorkflow', savedNodeState);
    }
    TileAPI.state.set('comfyui.connected', false);
    TileAPI.state.set('comfyui.running', false);
  },
});

// ========== 布局渲染 ==========

function _renderConnectionBar() {
  var url = TileAPI.storage.get('comfyui.url') || 'http://127.0.0.1:8188';
  return '' +
    '<div class="comfy-connection-bar">' +
      '<input class="w10-input comfy-url-input" id="comfyUrl" placeholder="http://127.0.0.1:8188" value="' + _esc(url) + '">' +
      '<button class="w10-btn w10-btn-accent" id="comfyConnectBtn">\u8FDE\u63A5</button>' +
      '<span class="comfy-status" id="comfyStatus">--</span>' +
    '</div>';
}

function _renderWorkflowSection() {
  return '' +
    '<div class="w10-section-title">\u5DE5\u4F5C\u6D41</div>' +
    '<div class="w10-row">' +
      '<div class="w10-row-left"><div class="w10-row-label">\u5F53\u524D</div></div>' +
      '<div class="w10-row-right" style="flex:1;display:flex;gap:4px;align-items:center;">' +
        '<select class="w10-select" id="comfyWorkflowSelect" style="flex:1;"><option value="">-- \u5DE5\u4F5C\u6D41 --</option></select>' +
        '<button class="w10-btn" id="comfyRefreshBtn" title="\u5237\u65B0\u5DE5\u4F5C\u6D41\u5217\u8868">\u5237\u65B0</button>' +
      '</div>' +
    '</div>' +
    '<div class="w10-row">' +
      '<div class="w10-row-right" style="display:flex;gap:4px;">' +
        '<button class="w10-btn" id="comfyLoadParamsBtn">\u52A0\u8F7D\u53C2\u6570</button>' +
        '<button class="w10-btn" id="comfyOpenFolderBtn">\u6253\u5F00\u6587\u4EF6\u5939</button>' +
      '</div>' +
    '</div>';
}

function _renderParamsSection() {
  return '' +
    '<div class="w10-section-title">\u53C2\u6570</div>' +
    '<div id="comfyParamsContainer" class="comfy-params-container">' +
      '<div style="font-size:10px;color:#888;text-align:center;padding:12px;">\u8BF7\u5148\u52A0\u8F7D\u5DE5\u4F5C\u6D41</div>' +
    '</div>';
}

function _renderActionBar() {
  var timeout = TileAPI.storage.get('comfyui.timeout') || 3600;
  return '' +
    '<div class="w10-section-title">\u64CD\u4F5C</div>' +
    '<input type="hidden" id="comfyTimeout" value="3600">' +
    '<div class="comfy-action-bar">' +
      '<div class="comfy-progress" id="comfyProgress" style="display:none;">' +
        '<div class="comfy-progress-bar" id="comfyProgressBar" style="width:0%;"></div>' +
        '<span class="comfy-progress-text" id="comfyProgressText">0%</span>' +
      '</div>' +
      '<div class="comfy-action-buttons">' +
        '<button class="w10-btn" id="comfyLoadImageBtn">\u52A0\u8F7D\u56FE\u50CF</button>' +
        '<span id="comfyTopImageButtons" class="comfy-top-image-buttons"></span>' +
        '<button class="w10-btn w10-btn-accent comfy-generate-btn" id="comfyGenerateBtn">\u25B6 ComfyUI \u751F\u6210</button>' +
      '</div>' +
    '</div>';
}

// --- Wide \u5E03\u5C40 (w>=2, h>=2) ---
function _renderWide(container) {
  container.innerHTML =
    '<div class="w10-panel comfy-panel comfy-layout-wide">' +
      '<div class="w10-section-title">\u8FDE\u63A5</div>' +
      _renderConnectionBar() +
      _renderWorkflowSection() +
      _renderActionBar() +
      _renderParamsSection() +
    '</div>';
}

// --- Narrow/Tall \u5E03\u5C40 (w=1) ---
function _renderNarrow(container) {
  var url = TileAPI.storage.get('comfyui.url') || 'http://127.0.0.1:8188';
  container.innerHTML =
    '<div class="w10-panel comfy-panel comfy-layout-narrow">' +
      '<div class="comfy-connection-bar">' +
        '<span class="comfy-status" id="comfyStatus">--</span>' +
      '</div>' +
      '<input type="hidden" id="comfyUrl" value="' + _esc(url) + '">' +
      '<select class="w10-select" id="comfyWorkflowSelect" style="width:100%;margin-bottom:4px;"><option value="">-- \u5DE5\u4F5C\u6D41 --</option></select>' +
      '<div class="comfy-action-buttons comfy-narrow-actions">' +
        '<button class="w10-btn" id="comfyLoadImageBtn">\u52A0\u8F7D\u56FE\u50CF</button>' +
        '<span id="comfyTopImageButtons" class="comfy-top-image-buttons"></span>' +
        '<button class="w10-btn w10-btn-accent comfy-generate-btn" id="comfyGenerateBtn">\u25B6 \u751F\u6210</button>' +
      '</div>' +
      '<div id="comfyParamsContainer" class="comfy-params-container"></div>' +
      '<div class="comfy-progress" id="comfyProgress" style="display:none;">' +
        '<div class="comfy-progress-bar" id="comfyProgressBar" style="width:0%;"></div>' +
        '<span class="comfy-progress-text" id="comfyProgressText">0%</span>' +
      '</div>' +
      '<button class="w10-btn" id="comfyConnectBtn" style="margin-top:4px;">\u8FDE\u63A5</button>' +
      '<button class="w10-btn" id="comfyRefreshBtn" style="display:none;">\u5237\u65B0</button>' +
      '<button class="w10-btn" id="comfyLoadParamsBtn" style="display:none;">\u52A0\u8F7D\u53C2\u6570</button>' +
      '<button class="w10-btn" id="comfyOpenFolderBtn" style="display:none;">\u6253\u5F00\u6587\u4EF6\u5939</button>' +
      '<input type="hidden" id="comfyTimeout" value="3600">' +
    '</div>';
}

// --- Square \u5E03\u5C40 ---
function _renderSquare(container) {
  var url = TileAPI.storage.get('comfyui.url') || 'http://127.0.0.1:8188';
  container.innerHTML =
    '<div class="w10-panel comfy-panel comfy-layout-square">' +
      '<div class="comfy-connection-bar">' +
        '<input class="w10-input comfy-url-input" id="comfyUrl" placeholder="http://127.0.0.1:8188" value="' + _esc(url) + '" style="max-width:160px;">' +
        '<button class="w10-btn w10-btn-accent" id="comfyConnectBtn">\u8FDE\u63A5</button>' +
        '<span class="comfy-status" id="comfyStatus">--</span>' +
      '</div>' +
      '<div class="comfy-square-grid">' +
        '<div class="comfy-square-left">' +
          '<select class="w10-select" id="comfyWorkflowSelect" style="width:100%;"><option value="">-- \u5DE5\u4F5C\u6D41 --</option></select>' +
          '<div style="display:flex;gap:4px;margin-top:4px;">' +
            '<button class="w10-btn" id="comfyRefreshBtn">\u5237\u65B0</button>' +
            '<button class="w10-btn" id="comfyLoadParamsBtn">\u52A0\u8F7D</button>' +
          '</div>' +
        '</div>' +
        '<div class="comfy-square-right"></div>' +
      '</div>' +
      '<div class="comfy-action-buttons comfy-square-actions">' +
        '<button class="w10-btn" id="comfyLoadImageBtn">\u52A0\u8F7D\u56FE\u50CF</button>' +
        '<span id="comfyTopImageButtons" class="comfy-top-image-buttons"></span>' +
        '<button class="w10-btn w10-btn-accent comfy-generate-btn" id="comfyGenerateBtn">\u25B6 \u751F\u6210</button>' +
      '</div>' +
      '<div id="comfyParamsContainer" class="comfy-params-container"></div>' +
      '<div class="comfy-progress" id="comfyProgress" style="display:none;">' +
        '<div class="comfy-progress-bar" id="comfyProgressBar" style="width:0%;"></div>' +
        '<span class="comfy-progress-text" id="comfyProgressText">0%</span>' +
      '</div>' +
      '<button class="w10-btn" id="comfyOpenFolderBtn" style="display:none;">\u6253\u5F00\u6587\u4EF6\u5939</button>' +
      '<input type="hidden" id="comfyTimeout" value="3600">' +
    '</div>';
}

// --- WideShort \u5E03\u5C40 (w>=3, h=1) ---
function _renderWideShort(container) {
  var url = TileAPI.storage.get('comfyui.url') || 'http://127.0.0.1:8188';
  container.innerHTML =
    '<div class="w10-panel comfy-panel comfy-layout-wideshort">' +
      '<div class="comfy-wideshort-strip">' +
        '<input class="w10-input comfy-url-input" id="comfyUrl" placeholder="http://127.0.0.1:8188" value="' + _esc(url) + '" style="max-width:200px;">' +
        '<button class="w10-btn w10-btn-accent" id="comfyConnectBtn">\u8FDE\u63A5</button>' +
        '<span class="comfy-status" id="comfyStatus">--</span>' +
        '<select class="w10-select" id="comfyWorkflowSelect" style="max-width:180px;"><option value="">-- \u5DE5\u4F5C\u6D41 --</option></select>' +
        '<button class="w10-btn" id="comfyLoadImageBtn">\u52A0\u8F7D\u56FE\u50CF</button>' +
        '<span id="comfyTopImageButtons" class="comfy-top-image-buttons"></span>' +
        '<button class="w10-btn w10-btn-accent comfy-generate-btn" id="comfyGenerateBtn">\u25B6 \u751F\u6210</button>' +
      '</div>' +
      '<div id="comfyParamsContainer" class="comfy-params-container" style="display:none;"></div>' +
      '<div class="comfy-progress" id="comfyProgress" style="display:none;">' +
        '<div class="comfy-progress-bar" id="comfyProgressBar" style="width:0%;"></div>' +
        '<span class="comfy-progress-text" id="comfyProgressText">0%</span>' +
      '</div>' +
      '<button class="w10-btn" id="comfyRefreshBtn" style="display:none;">\u5237\u65B0</button>' +
      '<button class="w10-btn" id="comfyLoadParamsBtn" style="display:none;">\u52A0\u8F7D\u53C2\u6570</button>' +
      '<button class="w10-btn" id="comfyOpenFolderBtn" style="display:none;">\u6253\u5F00\u6587\u4EF6\u5939</button>' +
      '<input type="hidden" id="comfyTimeout" value="3600">' +
    '</div>';
}

// 工作流使用单一下拉菜单，保留真实路径作为 option value，
// 这样旧的 change/load 链路和最近一次选择仍然兼容。
function _ensureWorkflowSelect(container) {
  var sel = container && container.querySelector('#comfyWorkflowSelect');
  if (!sel) return;
  sel.style.display = '';
}

function _ensureGallery(container) {
  if (!container) return;
  if (TileAPI.state.get('comfyui.galleryAutoReturn') === undefined) {
    TileAPI.state.set('comfyui.galleryAutoReturn', TileAPI.storage.get('output.autoReturn') !== false);
  }
  var panel = container.querySelector('.comfy-panel');
  if (!panel || panel.querySelector('#comfyResultGallery')) return _renderGallery(container);
  var gallery = document.createElement('div'); gallery.id = 'comfyResultGallery'; gallery.className = 'comfy-result-gallery';
  panel.appendChild(gallery); _renderGallery(container);
}

function _galleryItems() { return TileAPI.state.get('comfyui.results') || []; }

function _renderGallery(container) {
  var gallery = container && container.querySelector('#comfyResultGallery');
  if (!gallery) return;
  var items = _galleryItems();
  var index = Number(TileAPI.state.get('comfyui.resultIndex') || 0);
  if (index < 0) index = 0;
  if (index >= items.length) index = Math.max(0, items.length - 1);
  TileAPI.state.set('comfyui.resultIndex', index);
  gallery.innerHTML = '';
  var title = document.createElement('div'); title.className = 'comfy-result-title'; title.textContent = '生成结果' + (items.length ? ' (' + items.length + ')' : ''); gallery.appendChild(title);
  if (!items.length) { var empty = document.createElement('div'); empty.className = 'comfy-result-empty'; empty.textContent = '生成后在此查看结果'; gallery.appendChild(empty); return; }
  var toolbar = document.createElement('div'); toolbar.className = 'comfy-result-toolbar';
  var actions = [
    ['prev', '上一张'], ['next', '下一张'], ['send', '发送当前'], ['sendAll', '发送全部'],
    ['save', '保存当前'], ['saveAll', '保存全部'], ['copy', '复制'], ['delete', '删除当前'], ['clear', '清空']
  ];
  for (var ai = 0; ai < actions.length; ai++) {
    var btn = document.createElement('button'); btn.type = 'button'; btn.className = 'w10-btn'; btn.textContent = actions[ai][1]; btn.dataset.comfyGalleryAction = actions[ai][0]; toolbar.appendChild(btn);
  }
  var autoLabel = document.createElement('label'); autoLabel.className = 'comfy-result-auto';
  var auto = document.createElement('input'); auto.type = 'checkbox'; auto.checked = TileAPI.state.get('comfyui.galleryAutoReturn') !== false; auto.dataset.comfyGalleryAuto = '1';
  autoLabel.appendChild(auto); autoLabel.appendChild(document.createTextNode('自动发送')); toolbar.appendChild(autoLabel); gallery.appendChild(toolbar);
  var main = document.createElement('div'); main.className = 'comfy-result-main';
  var image = document.createElement('img'); image.src = _imageDataUrl(items[index].base64); image.alt = 'ComfyUI result ' + (index + 1); image.title = '点击切换预览大小';
  image.addEventListener('click', function() { main.classList.toggle('comfy-result-main-large'); }); main.appendChild(image);
  var caption = document.createElement('div'); caption.className = 'comfy-result-caption'; caption.textContent = (index + 1) + ' / ' + items.length + (items[index].returned ? ' · 已发送' : ''); main.appendChild(caption); gallery.appendChild(main);
  var thumbs = document.createElement('div'); thumbs.className = 'comfy-result-thumbs';
  for (var ti = 0; ti < items.length; ti++) {
    var thumb = document.createElement('button'); thumb.type = 'button'; thumb.className = 'comfy-result-thumb' + (ti === index ? ' selected' : ''); thumb.dataset.comfyResultIndex = String(ti);
    var thumbImg = document.createElement('img'); thumbImg.src = _imageDataUrl(items[ti].base64); thumbImg.alt = 'Result ' + (ti + 1); thumb.appendChild(thumbImg); thumbs.appendChild(thumb);
  }
  gallery.appendChild(thumbs); _bindGalleryEvents(container);
}

function _bindGalleryEvents(container) {
  var gallery = container.querySelector('#comfyResultGallery'); if (!gallery) return;
  var items = _galleryItems();
  var buttons = gallery.querySelectorAll('[data-comfyGalleryAction]');
  for (var i = 0; i < buttons.length; i++) buttons[i].addEventListener('click', function() {
    var action = this.dataset.comfyGalleryAction, idx = Number(TileAPI.state.get('comfyui.resultIndex') || 0), current = _galleryItems();
    if (action === 'prev' && current.length) idx = (idx + current.length - 1) % current.length;
    else if (action === 'next' && current.length) idx = (idx + 1) % current.length;
    else if (action === 'delete' && current.length) { current.splice(idx, 1); idx = Math.min(idx, Math.max(0, current.length - 1)); TileAPI.state.set('comfyui.results', current); }
    else if (action === 'clear') { TileAPI.state.set('comfyui.results', []); idx = 0; }
    else if (action === 'send' || action === 'sendAll') { _sendGalleryResults(action === 'sendAll' ? null : [idx]); return; }
    else if (action === 'save' || action === 'saveAll') { _saveGalleryResults(action === 'saveAll' ? null : [idx]); return; }
    else if (action === 'copy') { _copyGalleryResult(idx); return; }
    TileAPI.state.set('comfyui.resultIndex', idx); _renderGallery(container);
  });
  var thumbs = gallery.querySelectorAll('[data-comfyResultIndex]');
  for (var ti = 0; ti < thumbs.length; ti++) thumbs[ti].addEventListener('click', function() {
    TileAPI.state.set('comfyui.resultIndex', Number(this.dataset.comfyResultIndex)); _renderGallery(container);
  });
  var auto = gallery.querySelector('[data-comfyGalleryAuto]');
  if (auto) auto.addEventListener('change', function() { TileAPI.state.set('comfyui.galleryAutoReturn', !!this.checked); TileAPI.storage.set('output.autoReturn', !!this.checked); });
}

function _sendGalleryResults(indexes) {
  var items = _galleryItems(); var selected = indexes ? indexes.map(function(i) { return items[i]; }).filter(Boolean) : items.slice();
  if (!selected.length) return;
  TileAPI.sendToHost('comfyReturnResults', { taskId: TileAPI.state.get('comfyui.lastResultTaskId') || '', items: selected.map(function(it) { return { base64: it.base64, index: it.index, filename: it.filename, archiveId: it.archiveId }; }) });
}

function _saveGalleryResults(indexes) {
  var items = _galleryItems(); var selected = indexes ? indexes.map(function(i) { return items[i]; }).filter(Boolean) : items.slice();
  if (!selected.length) return;
  TileAPI.sendToHost('comfySaveResults', { taskId: TileAPI.state.get('comfyui.lastResultTaskId') || '', items: selected.map(function(it) { return { base64: it.base64, index: it.index, filename: it.filename }; }) });
}

function _copyGalleryResult(index) {
  var item = _galleryItems()[index]; if (!item || !item.base64) return;
  var text = _imageDataUrl(item.base64);
  if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(text).then(function() { TileAPI.toast('图像数据已复制', 'success'); }).catch(function() { TileAPI.toast('复制失败', 'error'); });
  else TileAPI.toast('当前环境不支持复制', 'warn');
}

// ========== \u4E8B\u4EF6\u7ED1\u5B9A ==========

function _bindCoreEvents(container) {
  // --- \u8FDE\u63A5 ---
  var connectBtn = container.querySelector('#comfyConnectBtn');
  if (connectBtn) connectBtn.addEventListener('click', function() {
    if (_comfyConnecting) { TileAPI.toast('\u6B63\u5728\u8FDE\u63A5\u4E2D\uFF0C\u8BF7\u7A0D\u5019...', 'warn'); return; }
    var urlInp = container.querySelector('#comfyUrl');
    var url = urlInp ? urlInp.value.trim().replace(/\/$/, '') : '';
    if (!url) { TileAPI.toast('\u8BF7\u8F93\u5165 ComfyUI \u5730\u5740', 'error'); return; }
    TileAPI.state.set('comfyui.url', url);
    TileAPI.storage.set('comfyui.url', url);
    _comfyConnecting = true;
    var statusEl = container.querySelector('#comfyStatus');
    if (statusEl) { statusEl.textContent = '\u8FDE\u63A5\u4E2D...'; statusEl.style.color = 'var(--text-sub)'; }
    TileAPI.sendToHost('comfyConnect', { url: url });
  });

  // --- URL \u6301\u4E45\u5316 ---
  var urlInp = container.querySelector('#comfyUrl');
  if (urlInp) urlInp.addEventListener('change', function() {
    TileAPI.storage.set('comfyui.url', urlInp.value.trim());
    TileAPI.state.set('comfyui.url', urlInp.value.trim());
  });

  // --- \u5237\u65B0\u5DE5\u4F5C\u6D41 ---
  var refreshBtn = container.querySelector('#comfyRefreshBtn');
  if (refreshBtn) refreshBtn.addEventListener('click', function() {
    TileAPI.sendToHost('comfyFetchWorkflows', { url: _getUrl() });
    TileAPI.toast('\u6B63\u5728\u5237\u65B0\u5DE5\u4F5C\u6D41\u5217\u8868...', 'info');
  });

  // --- \u5DE5\u4F5C\u6D41\u9009\u62E9 ---
  var wfSelect = container.querySelector('#comfyWorkflowSelect');
  if (wfSelect) wfSelect.addEventListener('change', function() {
    var wfName = wfSelect.value;
    if (!wfName) return;
    TileAPI.storage.set('comfyui.lastWorkflow', wfName);
    TileAPI.sendToHost('comfyLoadWorkflow', {
      url: _getUrl(),
      name: wfName,
      showAll: false,
      source: 'comfyTab'
    });
  });

  // 顶部快捷加载：复用 SD-PPP 的图像入口逻辑，自动选中当前工作流第一个图像参数。
  var loadImageBtn = container.querySelector('#comfyLoadImageBtn');
  if (loadImageBtn) loadImageBtn.addEventListener('click', function() {
    var images = _comfyImageParams();
    var imageParam = images.length ? images[0].key : '';
    if (!imageParam) {
      TileAPI.toast('\u5F53\u524D\u5DE5\u4F5C\u6D41\u6CA1\u6709\u53EF\u52A0\u8F7D\u56FE\u50CF\u7684\u8282\u70B9', 'warn');
      return;
    }
    _requestComfyImageCapture(imageParam, loadImageBtn);
  });

  // --- \u52A0\u8F7D\u53C2\u6570 ---
  var loadBtn = container.querySelector('#comfyLoadParamsBtn');
  if (loadBtn) loadBtn.addEventListener('click', function() {
    var wfSelect2 = container.querySelector('#comfyWorkflowSelect');
    var wfName = wfSelect2 ? wfSelect2.value : '';
    if (!wfName && !TileAPI.state.get('comfyui.currentWorkflow')) {
      TileAPI.toast('\u8BF7\u5148\u9009\u62E9\u5DE5\u4F5C\u6D41', 'error');
      return;
    }
    TileAPI.sendToHost('comfyLoadWorkflow', {
      url: _getUrl(),
      name: wfName,
      workflow: TileAPI.state.get('comfyui.currentWorkflow'),
      showAll: false,
      source: 'comfyTab'
    });
  });

  // --- \u6253\u5F00\u6587\u4EF6\u5939 ---
  var openFolderBtn = container.querySelector('#comfyOpenFolderBtn');
  if (openFolderBtn) openFolderBtn.addEventListener('click', function() {
    TileAPI.sendToHost('comfyOpenFolder', {});
  });

  // --- \u8D85\u65F6\u6ED1\u5757 ---
  _bindSlider(container, 'comfyTimeout', 'comfyTimeoutVal', 'comfyui.timeout');

  // --- \u751F\u6210 / \u4E2D\u65AD ---
  var genBtn = container.querySelector('#comfyGenerateBtn');
  if (genBtn) genBtn.addEventListener('click', function() {
    if (TileAPI.state.get('comfyui.running')) {
      TileAPI.sendToHost('comfyInterrupt', {
        url: _getUrl(),
        taskId: TileAPI.state.get('comfyui.currentTaskId') || ''
      });
      genBtn.textContent = '\u2573 \u4E2D\u65AD\u4E2D...';
      return;
    }
    var currentWorkflow = TileAPI.state.get('comfyui.currentWorkflow');
    if (!currentWorkflow) {
      TileAPI.toast('\u8BF7\u5148\u9009\u62E9\u5E76\u52A0\u8F7D\u5DE5\u4F5C\u6D41', 'error');
      return;
    }
    // \u6536\u96C6\u53C2\u6570
    var params = {};
    var enabledMap = TileAPI.state.get('comfyui.paramEnabled') || {};
    var paramEls = container.querySelectorAll('#comfyParamsContainer [data-comfy-param]');
    for (var i = 0; i < paramEls.length; i++) {
      var el = paramEls[i];
      if (el.disabled) continue;
      params[el.dataset.comfyParam] = el.type === 'checkbox' ? !!el.checked : el.value;
    }
    var timeoutEl = container.querySelector('#comfyTimeout');
    var timeout = timeoutEl ? parseInt(timeoutEl.value, 10) || 3600 : 3600;
    var needCapture = false;
    var imagePreviews = TileAPI.state.get('comfyui.imagePreviews') || {};
    for (var pi = 0; pi < paramEls.length; pi++) {
      var paramName = paramEls[pi].dataset.comfyParam || '';
      if (paramEls[pi].disabled) continue;
      if (/\.image$/i.test(paramName) || _isComfyImageParam({ name: paramName }) || imagePreviews[paramName]) { needCapture = true; break; }
    }

    TileAPI.state.set('comfyui.running', true);
    TileAPI.state.set('comfyui.nodeValues', params);
    _updateRunningUI(container, true);

    // 接入统一任务池(让任务磁贴显示 ComfyUI 运行状态)
    var taskId = 'comfy_' + Date.now() + '_' + Math.random().toString(36).substr(2, 6);
    var galleryAuto = TileAPI.state.get('comfyui.galleryAutoReturn');
    var autoReturn = galleryAuto === undefined ? (TileAPI.storage.get('output.autoReturn') !== false) : galleryAuto !== false;
    TileAPI.state.set('comfyui.currentTaskId', taskId);
    var running = TileAPI.state.get('tasks.running') || {};
    running[taskId] = { batchSize: 1, startTime: Date.now(), success: 0, fail: 0, total: 1, model: '🎛 ComfyUI' };
    TileAPI.state.set('tasks.running', running);
    var tmeta = TileAPI.state.get('tasks.meta') || {};
    tmeta[taskId] = { countdown: timeout, timeoutSec: timeout, autoReturn: autoReturn, batchSize: 1, engine: 'comfyui' };
    TileAPI.state.set('tasks.meta', tmeta);
    TileAPI.emit('tasks:updated');
    TileAPI.emit('task:started', { taskId: taskId, timeoutSec: timeout, batchSize: 1 });

    TileAPI.sendToHost('comfyGenerate', {
      url: _getUrl(),
      workflow: currentWorkflow,
      workflowName: TileAPI.state.get('comfyui.currentWorkflowName') || '',
      params: params,
      imagePreviews: imagePreviews,
      needCapture: needCapture,
      timeout: timeout,
      autoReturn: autoReturn,
      taskId: taskId
    });
  });
}

function _bindSlider(container, sliderId, valId, storageKey) {
  var slider = container.querySelector('#' + sliderId);
  var valEl = container.querySelector('#' + valId);
  if (!slider) return;
  slider.addEventListener('input', function() {
    if (valEl) valEl.textContent = slider.value;
    if (storageKey) TileAPI.storage.set(storageKey, slider.value);
  });
}

// ========== \u52A0\u8F7D\u4FDD\u5B58\u503C ==========

function _loadSavedValues(container) {
  var lastWf = TileAPI.storage.get('comfyui.lastWorkflow');
  if (lastWf) {
    var wfSelect = container.querySelector('#comfyWorkflowSelect');
    if (wfSelect) {
      // \u5C06\u5728\u5DE5\u4F5C\u6D41\u5217\u8868\u52A0\u8F7D\u540E\u9009\u4E2D
      TileAPI.state.set('comfyui._pendingSelectWf', lastWf);
    }
  }
}

// ========== \u8FD0\u884C\u72B6\u6001 UI ==========

function _updateRunningUI(container, running) {
  var btn = container.querySelector('#comfyGenerateBtn');
  var prog = container.querySelector('#comfyProgress');
  if (!btn) return;
  if (running) {
    btn.textContent = '\u25A0 \u4E2D\u65AD';
    btn.classList.remove('w10-btn-accent');
    btn.style.color = '#ff6b6b';
    btn.style.borderColor = 'rgba(255,100,100,0.3)';
    if (prog) prog.style.display = 'block';
  } else {
    btn.textContent = '\u25B6 ComfyUI \u751F\u6210';
    btn.classList.add('w10-btn-accent');
    btn.style.color = '';
    btn.style.borderColor = '';
    if (prog) prog.style.display = 'none';
  }
}

// ========== \u52A8\u6001\u53C2\u6570\u6E32\u67D3 ========== 

function _isComfyImageParam(p) {
  var name = String((p && (p.name || p.key || p.id)) || '');
  var type = String((p && p.type) || '').toLowerCase();
  var label = String((p && (p.label || p.displayName)) || '');
  return type === 'image' || type === 'imageupload' || /(?:^|[._-])(image|img|mask)(?:$|[._-])/i.test(name) || /图像|图片|蒙版|image|img|mask/i.test(label);
}

function _imageDataUrl(value) {
  if (!value) return '';
  var s = String(value);
  return s.indexOf('data:') === 0 ? s : 'data:image/png;base64,' + s;
}

function _bindComfyImageEvents(container) {
  var buttons = container.querySelectorAll('[data-comfy-capture]');
  for (var i = 0; i < buttons.length; i++) buttons[i].addEventListener('click', function() {
    var name = this.dataset.comfyCapture;
    TileAPI.state.set('comfyui.captureParam', name);
    this.disabled = true;
    this.textContent = '\u6293\u53D6\u4E2D...';
    TileAPI.sendToHost('comfyCaptureImage', { param: name });
  });
  var clears = container.querySelectorAll('[data-comfy-clear-image]');
  for (var j = 0; j < clears.length; j++) clears[j].addEventListener('click', function() {
    var name = this.dataset.comfyClearImage;
    var previews = TileAPI.state.get('comfyui.imagePreviews') || {};
    delete previews[name];
    TileAPI.state.set('comfyui.imagePreviews', previews);
    _renderComfyParams(container, TileAPI.state.get('comfyui.currentNodes') || []);
  });
}

function _bindComfyParamToggles(container) {
  var toggles = container.querySelectorAll('[data-comfy-param-toggle]');
  for (var i = 0; i < toggles.length; i++) toggles[i].addEventListener('change', function() {
    var name = this.dataset.comfyParamToggle;
    var enabled = !!this.checked;
    var enabledMap = TileAPI.state.get('comfyui.paramEnabled') || {};
    enabledMap[name] = enabled;
    TileAPI.state.set('comfyui.paramEnabled', enabledMap);
    var row = this.closest ? this.closest('.comfy-param-row') : null;
    if (row) row.classList.toggle('comfy-param-disabled', !enabled);
    var fields = row ? row.querySelectorAll('[data-comfy-param]') : [];
    for (var j = 0; j < fields.length; j++) fields[j].disabled = !enabled;
    var imageButtons = row ? row.querySelectorAll('[data-comfy-capture],[data-comfy-clear-image]') : [];
    for (var k = 0; k < imageButtons.length; k++) imageButtons[k].disabled = !enabled;
  });
}

function _renderComfyParamsLegacy(container, paramsDef) {
  var paramsEl = container.querySelector('#comfyParamsContainer');
  if (!paramsEl) return;
  paramsEl.innerHTML = '';

  if (!paramsDef || paramsDef.length === 0) {
    paramsEl.innerHTML = '<div style="font-size:10px;color:#888;text-align:center;padding:12px;">\u6B64\u5DE5\u4F5C\u6D41\u65E0\u53EF\u8C03\u53C2\u6570</div>';
    return;
  }

  // \u8BD5\u56FE\u6062\u590D\u4E0A\u6B21\u4FDD\u5B58\u7684\u503C
  var savedValues = TileAPI.state.get('comfyui.nodeValues') || {};

  for (var i = 0; i < paramsDef.length; i++) {
    var p = paramsDef[i];
    var row = document.createElement('div');
    row.className = 'w10-row comfy-param-row';

    var label = document.createElement('div');
    label.className = 'w10-row-left';
    label.innerHTML = '<div class="w10-row-label" title="' + _esc(p.name) + '">' + _esc(p.label || p.name) + '</div>';
    row.appendChild(label);

    var right = document.createElement('div');
    right.className = 'w10-row-right';
    right.style.flex = '1';

    var input;
    var savedVal = savedValues[p.name];
    var defaultVal = savedVal !== undefined ? savedVal : p.default;

    if (p.type === 'select' && p.options) {
      input = document.createElement('select');
      input.className = 'w10-select';
      for (var oi = 0; oi < p.options.length; oi++) {
        var o = document.createElement('option');
        o.value = p.options[oi];
        o.textContent = p.options[oi];
        input.appendChild(o);
      }
      if (defaultVal !== undefined) input.value = String(defaultVal);
    } else if (p.type === 'textarea') {
      input = document.createElement('textarea');
      input.className = 'w10-input comfy-param-textarea';
      input.rows = 3;
      input.value = defaultVal !== undefined ? String(defaultVal) : '';
    } else if (p.type === 'number') {
      input = document.createElement('input');
      input.type = 'number';
      input.className = 'w10-input';
      input.value = defaultVal !== undefined ? defaultVal : '';
      if (p.min !== undefined) input.min = p.min;
      if (p.max !== undefined) input.max = p.max;
      if (p.step !== undefined) input.step = p.step;
    } else {
      input = document.createElement('input');
      input.type = 'text';
      input.className = 'w10-input';
      input.value = defaultVal !== undefined ? String(defaultVal) : '';
    }

    input.dataset.comfyParam = p.name;
    if (p.disabled) { input.disabled = true; input.style.opacity = '0.5'; }

    right.appendChild(input);
    if (/\.image$/i.test(p.name || '')) {
      var hint = document.createElement('div');
      hint.style.cssText = 'font-size:10px;color:var(--text-sub);margin-top:3px;';
      hint.textContent = '生成时自动使用 Photoshop 当前选区图像';
      right.appendChild(hint);
    }
    row.appendChild(right);
    paramsEl.appendChild(row);
  }
}

// Image-aware interactive renderer.
function _renderComfyParams(container, paramsDef) {
  var paramsEl = container.querySelector('#comfyParamsContainer');
  if (!paramsEl) return;
  paramsEl.innerHTML = '';
  if (!paramsDef || !paramsDef.length) {
    paramsEl.innerHTML = '<div style="font-size:10px;color:#888;text-align:center;padding:12px;">无可调参数</div>';
    return;
  }
  var saved = TileAPI.state.get('comfyui.nodeValues') || {};
  var previews = TileAPI.state.get('comfyui.imagePreviews') || {};
  var enabledMap = TileAPI.state.get('comfyui.paramEnabled') || {};
  for (var i = 0; i < paramsDef.length; i++) {
    var p = paramsDef[i];
    var enabled = enabledMap[p.name] !== false;
    var row = document.createElement('div'); row.className = 'w10-row comfy-param-row' + (enabled ? '' : ' comfy-param-disabled');
    var label = document.createElement('div'); label.className = 'w10-row-left';
    var toggle = document.createElement('input'); toggle.type = 'checkbox'; toggle.checked = enabled; toggle.title = '勾选后显示并启用此参数'; toggle.dataset.comfyParamToggle = p.name;
    label.appendChild(toggle);
    var labelText = document.createElement('div'); labelText.className = 'w10-row-label'; labelText.title = p.name; labelText.textContent = p.label || p.name;
    label.appendChild(labelText);
    row.appendChild(label);
    var right = document.createElement('div'); right.className = 'w10-row-right'; right.style.flex = '1';
    var val = saved[p.name] !== undefined ? saved[p.name] : p.default;
    var input;
    if (_isComfyImageParam(p)) {
      var editor = document.createElement('div'); editor.className = 'comfy-image-editor';
      var actions = document.createElement('div'); actions.className = 'comfy-image-actions';
      var load = document.createElement('button'); load.type = 'button'; load.className = 'w10-btn w10-btn-accent'; load.textContent = '加载图像'; load.dataset.comfyCapture = p.name;
      var clear = document.createElement('button'); clear.type = 'button'; clear.className = 'w10-btn'; clear.textContent = '清除'; clear.dataset.comfyClearImage = p.name;
      actions.appendChild(load); actions.appendChild(clear); editor.appendChild(actions);
      var preview = document.createElement('div'); preview.className = 'comfy-image-preview';
      if (previews[p.name]) { var img = document.createElement('img'); img.src = _imageDataUrl(previews[p.name]); img.alt = 'Photoshop selection preview'; preview.appendChild(img); }
      else { var ph = document.createElement('div'); ph.className = 'comfy-image-placeholder'; ph.textContent = '未加载图像，点击“加载图像”抓取 Photoshop 当前选区'; preview.appendChild(ph); }
      editor.appendChild(preview);
      input = document.createElement('input'); input.type = 'hidden'; input.value = val !== undefined ? String(val) : ''; input.dataset.comfyParam = p.name; editor.appendChild(input); right.appendChild(editor);
    } else if (p.type === 'select' && p.options) {
      input = document.createElement('select'); input.className = 'w10-select';
      for (var oi = 0; oi < p.options.length; oi++) { var opt = document.createElement('option'); opt.value = p.options[oi]; opt.textContent = p.options[oi]; input.appendChild(opt); }
      if (val !== undefined) input.value = String(val);
      right.appendChild(input);
    } else if (p.type === 'textarea') {
      input = document.createElement('textarea'); input.className = 'w10-input comfy-param-textarea'; input.rows = 3; input.value = val !== undefined ? String(val) : ''; right.appendChild(input);
    } else if (p.type === 'number') {
      input = document.createElement('input'); input.type = 'number'; input.className = 'w10-input'; input.value = val !== undefined ? val : '';
      if (p.min !== undefined) input.min = p.min; if (p.max !== undefined) input.max = p.max; if (p.step !== undefined) input.step = p.step; right.appendChild(input);
    } else {
      input = document.createElement('input'); input.type = 'text'; input.className = 'w10-input'; input.value = val !== undefined ? String(val) : ''; right.appendChild(input);
    }
    input.dataset.comfyParam = p.name;
    if (p.disabled || !enabled) { input.disabled = true; input.style.opacity = '0.5'; }
    row.appendChild(right); paramsEl.appendChild(row);
  }
  _bindComfyImageEvents(container);
  _bindComfyParamToggles(container);
}

function _comfyParamGroup(p) {
  var label = String((p && p.label) || p.name || '工作流参数');
  var cut = label.indexOf(' / ');
  return cut > 0 ? label.slice(0, cut) : label.replace(/\s*\/\s*[^/]+$/, '') || '工作流参数';
}

function _bindComfyGroupToggles(container) {
  function setExpanded(toggle, enabled) {
    if (!toggle) return;
    var isButton = String(toggle.tagName || '').toLowerCase() === 'button';
    if (isButton) {
      toggle.textContent = enabled ? '\u25B2' : '\u25BC';
      toggle.title = enabled ? '收起节点' : '展开节点';
      toggle.setAttribute('aria-label', enabled ? '收起节点' : '展开节点');
    } else {
      toggle.checked = enabled;
    }
    toggle.setAttribute('aria-expanded', enabled ? 'true' : 'false');
    var key = toggle.dataset.comfyGroupToggle;
    var all = TileAPI.state.get('comfyui.nodeEnabledByWorkflow') || {};
    var wfKey = _comfyWorkflowKey();
    var state = all[wfKey] || {};
    state[key] = enabled;
    all[wfKey] = state;
    TileAPI.state.set('comfyui.nodeEnabledByWorkflow', all);
    TileAPI.storage.set('comfyui.nodeEnabledByWorkflow', all);
    // 兼容其它旧 UI 读取的状态键，但该状态不参与参数提交。
    TileAPI.state.set('comfyui.nodeEnabled', state);
    var card = toggle.closest('.comfy-node-card');
    var details = card ? card.querySelector('[data-comfy-group-details]') : null;
    if (details) {
      details.style.display = enabled ? '' : 'none';
      details.setAttribute('aria-hidden', enabled ? 'false' : 'true');
    }
    if (card) card.classList.toggle('comfy-node-collapsed', !enabled);
  }
  var toggles = container.querySelectorAll('[data-comfy-group-toggle]');
  for (var i = 0; i < toggles.length; i++) toggles[i].addEventListener('click', function(e) {
    if (String(this.tagName || '').toLowerCase() !== 'button') return;
    if (e && e.preventDefault) e.preventDefault();
    setExpanded(this, this.getAttribute('aria-expanded') !== 'true');
  });
  for (var c = 0; c < toggles.length; c++) toggles[c].addEventListener('change', function() {
    if (String(this.tagName || '').toLowerCase() === 'button') return;
    setExpanded(this, !!this.checked);
  });
  var headers = container.querySelectorAll('.comfy-node-header');
  for (var h = 0; h < headers.length; h++) headers[h].addEventListener('click', function(e) {
    if (e.target && (e.target.matches('input[type="checkbox"]') || e.target.closest('[data-comfy-group-toggle]'))) return;
    var toggle = this.querySelector('[data-comfy-group-toggle]');
    if (toggle) {
      var isButton = String(toggle.tagName || '').toLowerCase() === 'button';
      setExpanded(toggle, isButton ? toggle.getAttribute('aria-expanded') !== 'true' : !toggle.checked);
    }
  });
}

function _bindComfyNodeOrder(container) {
  var handles = container.querySelectorAll('[data-comfy-drag-handle]');
  for (var i = 0; i < handles.length; i++) {
    handles[i].addEventListener('dragstart', function(e) {
      var card = this.closest('.comfy-key-node-card');
      if (!card) return;
      card.classList.add('comfy-node-dragging');
      if (e && e.dataTransfer) {
        e.dataTransfer.effectAllowed = 'move';
        e.dataTransfer.setData('text/plain', String(card.dataset.comfyKeyNode || ''));
      }
      container._comfyDraggingCard = card;
    });
    handles[i].addEventListener('dragend', function() {
      var card = this.closest('.comfy-key-node-card');
      if (card) card.classList.remove('comfy-node-dragging');
      container._comfyDraggingCard = null;
      var cards = container.querySelectorAll('.comfy-key-node-card');
      for (var ci = 0; ci < cards.length; ci++) cards[ci].classList.remove('comfy-node-drag-over');
    });
  }
  var cardsForDrop = container.querySelectorAll('.comfy-key-node-card');
  for (var c = 0; c < cardsForDrop.length; c++) {
    cardsForDrop[c].addEventListener('dragover', function(e) {
      var dragging = container._comfyDraggingCard;
      if (!dragging || dragging === this) return;
      if (e && e.preventDefault) e.preventDefault();
      this.classList.add('comfy-node-drag-over');
      if (e && e.dataTransfer) e.dataTransfer.dropEffect = 'move';
    });
    cardsForDrop[c].addEventListener('dragleave', function() {
      this.classList.remove('comfy-node-drag-over');
    });
    cardsForDrop[c].addEventListener('drop', function(e) {
      if (e && e.preventDefault) e.preventDefault();
      var dragging = container._comfyDraggingCard;
      if (!dragging || dragging === this) return;
      var parent = this.parentNode;
      var rect = this.getBoundingClientRect ? this.getBoundingClientRect() : null;
      var insertAfter = rect && e && e.clientY > rect.top + rect.height / 2;
      if (insertAfter) parent.insertBefore(dragging, this.nextSibling);
      else parent.insertBefore(dragging, this);
      this.classList.remove('comfy-node-drag-over');
      var cards = parent.querySelectorAll('.comfy-key-node-card');
      var order = [];
      for (var ci = 0; ci < cards.length; ci++) order.push(String(cards[ci].dataset.comfyKeyNode || ''));
      _saveComfyKeyNodeOrder(order);
    });
  }
}

// SD-PPP widget 编辑是即时状态：折叠节点、切换预览或重新渲染时，已填写的值不能丢失。
function _bindComfyValueEvents(container) {
  var fields = container.querySelectorAll('#comfyParamsContainer [data-comfy-param]');
  for (var i = 0; i < fields.length; i++) {
    fields[i].addEventListener('input', _saveComfyFieldValue);
    fields[i].addEventListener('change', _saveComfyFieldValue);
  }
}

function _saveComfyFieldValue(e) {
  var field = e && e.currentTarget ? e.currentTarget : e;
  if (!field || !field.dataset || !field.dataset.comfyParam) return;
  var values = TileAPI.state.get('comfyui.nodeValues') || {};
  var value;
  if (field.type === 'checkbox') value = !!field.checked;
  else if (String(field.tagName || '').toLowerCase() === 'select' && field.multiple) {
    value = [];
    var options = field.options || [];
    for (var oi = 0; oi < options.length; oi++) if (options[oi].selected) value.push(options[oi].value);
  }
  else if (field.type === 'number') value = field.value === '' ? '' : Number(field.value);
  else value = field.value;
  values[field.dataset.comfyParam] = value;
  TileAPI.state.set('comfyui.nodeValues', values);
}

function _comfyImageParams() {
  var nodes = TileAPI.state.get('comfyui.currentNodes') || [], result = [];
  for (var ni = 0; ni < nodes.length; ni++) {
    var node = nodes[ni] || {}, nodeId = String(node.id || node.nodeId || ni), widgets = node.widgets || [];
    for (var wi = 0; wi < widgets.length; wi++) {
      var widget = widgets[wi] || {};
      if (widget.isImageInput || (widget.widgetType !== 'CONNECTED' && _isComfyImageParam({ name: widget.name, type: widget.widgetType }))) {
        result.push({ key: nodeId + '.' + String(widget.name || wi), name: String(widget.name || wi) });
      }
    }
  }
  return result;
}

function _requestComfyImageCapture(param, button) {
  TileAPI.state.set('comfyui.captureParam', param);
  if (button) { button.disabled = true; button.textContent = '\u52A0\u8F7D\u4E2D...'; }
  TileAPI.sendToHost('comfyCaptureImage', { param: param });
}

function _renderComfyTopImageButtons(container) {
  var host = container && container.querySelector('#comfyTopImageButtons');
  if (!host) return;
  host.innerHTML = '';
  var images = _comfyImageParams();
  for (var i = 0; i < images.length; i++) {
    var button = document.createElement('button');
    button.type = 'button'; button.className = 'w10-btn comfy-reference-image-btn';
    button.textContent = images.length === 1 ? '\u53C2\u8003\u56FE' : '\u53C2\u8003\u56FE ' + (i + 1);
    button.title = images[i].key; button.dataset.comfyTopImage = images[i].key;
    button.addEventListener('click', function() { _requestComfyImageCapture(this.dataset.comfyTopImage, this); });
    host.appendChild(button);
  }
}

// SD-PPP 的折叠状态按工作流保存。普通工作流默认展开核心参数；
// 魔法禁书目录这类参数很多的工作流默认折叠，由用户逐个打开查看。
function _comfyWorkflowKey() {
  var name = String(TileAPI.state.get('comfyui.currentWorkflowName') || '');
  return name || 'comfyui:untitled';
}

function _comfyDefaultNodeExpanded() {
  return !/魔法禁书/i.test(_comfyWorkflowKey());
}

// 只把用户真正需要改动的入口节点放进面板。其余节点仍保留在原始
// workflow 中，由 workflow-engine 使用原值生成，不在 UI 中占空间。
function _comfyNodePriority(node) {
  node = node || {};
  var typeText = String(node.type || node.class_type || '').toLowerCase();
  var titleText = String(node.title || node.name || '').toLowerCase();
  var widgetText = (node.widgets || []).map(function(widget) {
    return String(widget && widget.name || '').toLowerCase();
  }).join(' ');
  var text = typeText + ' ' + titleText + ' ' + widgetText;

  if (/loadimage|ps\s*bridge.*image|image\s*loader/.test(text) && /mask/.test(text)) return 0;
  if (/loadimage|ps\s*bridge.*image|image\s*loader/.test(text)) return 1;
  if (/cliptextencode|textencode|prompt|positive|negative|caption/.test(text)) return 10;
  if (/ksampler|samplercustom|sampler|scheduler/.test(text) || /\b(seed|steps|cfg|denoise)\b/.test(widgetText)) return 20;
  if (/emptylatent|latentimage|latent/.test(text) || /\b(width|height|batch|size)\b/.test(widgetText)) return 30;
  if (/checkpoint|unetloader|vaeloader|cliploader|model/.test(text)) return 40;
  return -1;
}

function _comfyKeyNodeOrder(nodes) {
  var workflowKey = _comfyWorkflowKey();
  var all = TileAPI.state.get('comfyui.keyNodeOrder') || {};
  var ids = nodes.map(function(node, index) { return String(node && (node.id || node.nodeId) || index); });
  var saved = Array.isArray(all[workflowKey]) ? all[workflowKey] : [];
  var result = [];
  for (var i = 0; i < saved.length; i++) if (ids.indexOf(String(saved[i])) >= 0 && result.indexOf(String(saved[i])) < 0) result.push(String(saved[i]));
  for (var j = 0; j < ids.length; j++) if (result.indexOf(ids[j]) < 0) result.push(ids[j]);
  return result;
}

function _saveComfyKeyNodeOrder(order) {
  var all = TileAPI.state.get('comfyui.keyNodeOrder') || {};
  var normalized = [];
  for (var i = 0; i < order.length; i++) {
    var id = String(order[i] || '');
    if (id && normalized.indexOf(id) < 0) normalized.push(id);
  }
  all[_comfyWorkflowKey()] = normalized;
  TileAPI.state.set('comfyui.keyNodeOrder', all);
  // 按工作流名称保存，确保下次打开插件或 Photoshop 时仍恢复用户顺序。
  TileAPI.storage.set('comfyui.keyNodeOrder', all);
}

function _comfyFriendlyNodeTitle(node, key) {
  node = node || {};
  var title = String(node.title || '').replace(/^@37\s*/i, '').trim();
  var type = String(node.type || node.class_type || '').trim();
  var text = (title + ' ' + type).toLowerCase();
  var opaque = !title || /^(?:node\s*)?\d+$/i.test(title) || /^[0-9a-f]{8,}(?:-[0-9a-f]+)+$/i.test(title) || /^[0-9a-f]{16,}$/i.test(title);
  if (/loadimagemask|ps\s*bridge.*mask|mask.*loader/.test(text)) return '输入蒙版';
  if (/loadimage|ps\s*bridge.*image|image\s*loader/.test(text)) return '输入图像';
  if (/cliptextencode|textencode|positive/.test(text)) return '正向提示词';
  if (/negative/.test(text)) return '反向提示词';
  if (/ksampler|samplercustom|sampler|scheduler/.test(text)) return '采样参数';
  if (/emptylatent|latentimage|latent/.test(text)) return '画布尺寸';
  if (/checkpoint|unetloader|vaeloader|cliploader|model/.test(text)) return '模型';
  return opaque ? (type || '关键输入') : title;
}

function _comfyWidgetLabel(node, widget, index) {
  widget = widget || {};
  var raw = String(widget.name || '').trim();
  if (!/^(?:value|text|string|param_\d+)$/i.test(raw)) return String((widget.config && widget.config.label) || raw || '参数');
  var text = String((node && (node.type || node.class_type || node.title)) || '').toLowerCase();
  if (/loadimagemask|mask/.test(text)) return '蒙版';
  if (/loadimage/.test(text)) return '图像';
  if (/cliptextencode|textencode|prompt/.test(text)) return '提示词';
  if (/ksampler|sampler/.test(text)) return ['种子', '步数', 'CFG', '采样器', '调度器', '降噪'][index] || ('参数 ' + (index + 1));
  if (/emptylatent|latentimage/.test(text)) return ['宽度', '高度', '批次'][index] || ('参数 ' + (index + 1));
  return '参数 ' + (index + 1);
}

function _comfyNodeEnabledState(nodes) {
  var all = TileAPI.state.get('comfyui.nodeEnabledByWorkflow') || {};
  var key = _comfyWorkflowKey();
  var state = all[key];
  if (!state || typeof state !== 'object') {
    state = {};
    var expanded = _comfyDefaultNodeExpanded();
    for (var i = 0; i < nodes.length; i++) {
      var id = String((nodes[i] && (nodes[i].id || nodes[i].nodeId)) || i);
      state[id] = expanded;
    }
    all[key] = state;
    TileAPI.state.set('comfyui.nodeEnabledByWorkflow', all);
  }
  return state;
}

// 兼容旧版主机只返回扁平 params 的消息，统一转换为 SD-PPP 节点结构。
function _normalizeComfyNodes(defs) {
  if (!Array.isArray(defs) || !defs.length) return [];
  function isHiddenHelper(node) {
    var text = String((node && (node.title || node.type || node.name || node.class_type)) || '');
    return /^(?:PrimitiveString|PrimitiveInt|PrimitiveFloat|PrimitiveBool|PrimitiveBoolean|PrimitiveNode|Reroute|Note)$/i.test(text.trim());
  }
  if (defs[0] && Array.isArray(defs[0].widgets)) return defs.filter(function(node) { return !isHiddenHelper(node); });
  var groups = {};
  for (var i = 0; i < defs.length; i++) {
    var p = defs[i] || {};
    if (isHiddenHelper(p)) continue;
    var name = String(p.name || p.key || ('param_' + i));
    var dot = name.indexOf('.');
    var id = dot > 0 ? name.slice(0, dot) : 'workflow';
    var widgetName = dot > 0 ? name.slice(dot + 1) : name;
    if (!groups[id]) groups[id] = { id: id, nodeId: id, title: p.label ? String(p.label).split(' / ')[0] : id, type: '', widgets: [] };
    var wt = p.type === 'number' ? 'FLOAT' : p.type === 'select' ? 'COMBO' : p.type === 'textarea' ? 'STRING' : 'STRING';
  groups[id].widgets.push({ name: widgetName, widgetType: wt, config: { options: p.options || [], labels: p.labels || [], multiple: !!(p.multiple || p.multi_select || p.multiselect || p.multiSelect || p.allow_multiple || p.allowMultiple), multiline: p.type === 'textarea', min: p.min, max: p.max, step: p.step }, value: p.default, isConnected: !!p.disabled, isImageInput: _isComfyImageParam(p) });
  }
  var out = [];
  for (var key in groups) out.push(groups[key]);
  return out;
}

function _comfyWidgetAllowsMultiple(widget) {
  var cfg = (widget && widget.config) || {};
  return cfg.multiple === true || cfg.multi_select === true || cfg.multiselect === true || cfg.multiSelect === true || cfg.allow_multiple === true || cfg.allowMultiple === true;
}

function _setComfySelectValue(select, value) {
  if (!select || value === undefined || value === null) return;
  if (select.multiple) {
    var selected = Array.isArray(value) ? value.map(function(item) { return String(item); }) : [String(value)];
    var options = select.options || [];
    for (var oi = 0; oi < options.length; oi++) options[oi].selected = selected.indexOf(String(options[oi].value)) >= 0;
  } else {
    select.value = String(value);
  }
}

// SD-PPP node/widget renderer. The header triangle folds a node only; it never
// disables the node or drops its untouched values from the submitted workflow.
function _renderComfyParams(container, paramsDef) {
  var paramsEl = container.querySelector('#comfyParamsContainer');
  if (!paramsEl) return;
  paramsEl.innerHTML = '';
  if (!paramsDef || !paramsDef.length) {
    paramsEl.innerHTML = '<div style="font-size:10px;color:#888;text-align:center;padding:12px;">无可调参数</div>';
    return;
  }
  var saved = TileAPI.state.get('comfyui.nodeValues') || {};
  var previews = TileAPI.state.get('comfyui.imagePreviews') || {};
  var nodes = _normalizeComfyNodes(paramsDef);
  var ranked = [];
  for (var ri = 0; ri < nodes.length; ri++) {
    var rank = _comfyNodePriority(nodes[ri]);
    if (rank >= 0) ranked.push({ node: nodes[ri], rank: rank, index: ri });
  }
  if (!ranked.length) {
    paramsEl.innerHTML = '<div class="comfy-key-params-empty">当前工作流没有可识别的关键输入</div>';
    return;
  }
  var keyOrder = _comfyKeyNodeOrder(ranked.map(function(entry) { return entry.node; }));
  ranked.sort(function(a, b) {
    var ai = keyOrder.indexOf(String(a.node && (a.node.id || a.node.nodeId) || a.index));
    var bi = keyOrder.indexOf(String(b.node && (b.node.id || b.node.nodeId) || b.index));
    return ai - bi;
  });
  var nodeState = _comfyNodeEnabledState(nodes);
  for (var g = 0; g < ranked.length; g++) {
    var rankedNode = ranked[g], node = rankedNode.node || {}, key = String(node.id || node.nodeId || rankedNode.index);
    var enabled = nodeState[key] !== undefined ? !!nodeState[key] : true;
    var card = document.createElement('div'); card.className = 'comfy-node-card comfy-key-node-card' + (enabled ? '' : ' comfy-node-collapsed'); card.dataset.comfyKeyNode = key;
    var head = document.createElement('div'); head.className = 'comfy-node-header';
    var toggle = document.createElement('button'); toggle.type = 'button'; toggle.className = 'comfy-node-toggle'; toggle.textContent = enabled ? '\u25B2' : '\u25BC'; toggle.title = enabled ? '收起节点' : '展开节点'; toggle.dataset.comfyGroupToggle = key; toggle.setAttribute('aria-label', enabled ? '收起节点' : '展开节点'); toggle.setAttribute('aria-expanded', enabled ? 'true' : 'false'); toggle.draggable = false;
    var title = document.createElement('span'); title.className = 'comfy-node-title'; title.textContent = _comfyFriendlyNodeTitle(node, key);
    head.title = '拖动此标题调整关键输入顺序';
    head.draggable = true;
    head.dataset.comfyDragHandle = key;
    head.appendChild(title); head.appendChild(toggle); card.appendChild(head);
    var details = document.createElement('div'); details.className = 'comfy-node-details'; details.dataset.comfyGroupDetails = key; details.style.display = enabled ? '' : 'none'; details.setAttribute('aria-hidden', enabled ? 'false' : 'true');
    var list = node.widgets || [];
    for (var j = 0; j < list.length; j++) {
      var p = list[j], cfg = p.config || {}, paramName = key + '.' + String(p.name || j), row = document.createElement('div'); row.className = 'w10-row comfy-param-row';
      var rawWidgetName = String(p.name || '');
      var hideGenericLabel = /^(?:value|text|string|param_\d+)$/i.test(rawWidgetName.trim());
      var label = document.createElement('div'); label.className = 'w10-row-left'; label.textContent = _comfyWidgetLabel(node, p, j); label.title = label.textContent; row.appendChild(label);
      var right = document.createElement('div'); right.className = 'w10-row-right'; right.style.flex = '1';
      var val = saved[paramName] !== undefined ? saved[paramName] : p.value, input, editor = null;
      if (p.isConnected) {
        input = document.createElement('input'); input.type = 'text'; input.className = 'w10-input comfy-connected-input';
        input.value = val !== undefined ? String(val) : '已连接'; input.disabled = true; input.title = '该参数由工作流连接提供'; right.appendChild(input);
      } else if (p.isImageInput || _isComfyImageParam({ name: paramName, type: p.widgetType })) {
        var editor = document.createElement('div'); editor.className = 'comfy-image-editor';
        var actions = document.createElement('div'); actions.className = 'comfy-image-actions';
        var load = document.createElement('button'); load.type = 'button'; load.className = 'w10-btn w10-btn-accent'; load.textContent = '加载图像'; load.dataset.comfyCapture = paramName;
        var clear = document.createElement('button'); clear.type = 'button'; clear.className = 'w10-btn'; clear.textContent = '清除'; clear.dataset.comfyClearImage = paramName;
        actions.appendChild(load); actions.appendChild(clear); editor.appendChild(actions);
        var preview = document.createElement('div'); preview.className = 'comfy-image-preview';
        if (previews[paramName]) { var img = document.createElement('img'); img.src = _imageDataUrl(previews[paramName]); img.alt = 'Photoshop selection preview'; preview.appendChild(img); }
        else { var ph = document.createElement('div'); ph.className = 'comfy-image-placeholder'; ph.textContent = '未加载图像，点击“加载图像”抓取 Photoshop 当前选区'; preview.appendChild(ph); }
        editor.appendChild(preview); input = document.createElement('input'); input.type = 'hidden'; input.value = val !== undefined ? String(val) : ''; input.dataset.comfyParam = paramName; editor.appendChild(input); right.appendChild(editor);
      } else if ((p.widgetType === 'COMBO' || p.widgetType === 'SEGMENT' || cfg.options || cfg.values) && (cfg.options || cfg.values)) {
        input = document.createElement('select'); input.className = 'w10-select';
        input.multiple = _comfyWidgetAllowsMultiple(p);
        if (input.multiple) input.className += ' comfy-multi-select';
        var options = cfg.options || cfg.values || [], labels = cfg.labels || [];
        for (var oi = 0; oi < options.length; oi++) { var opt = document.createElement('option'); opt.value = options[oi]; opt.textContent = labels[oi] !== undefined ? labels[oi] : options[oi]; input.appendChild(opt); }
        _setComfySelectValue(input, val); right.appendChild(input);
      } else if (p.widgetType === 'BOOL' || p.widgetType === 'TOGGLE') {
        input = document.createElement('input'); input.type = 'checkbox'; input.checked = val === true || String(val) === 'true' || String(val) === '1'; right.appendChild(input);
      } else if (p.widgetType === 'STRING' && (cfg.multiline || hideGenericLabel)) {
        input = document.createElement('textarea'); input.className = 'w10-input comfy-param-textarea'; input.rows = 3; input.value = val !== undefined ? String(val) : ''; right.appendChild(input);
      } else if (p.widgetType === 'INT' || p.widgetType === 'FLOAT' || p.widgetType === 'NUMBER') {
        input = document.createElement('input'); input.type = 'number'; input.className = 'w10-input'; input.value = val !== undefined ? val : '';
        if (cfg.min !== undefined) input.min = cfg.min; if (cfg.max !== undefined) input.max = cfg.max; input.step = cfg.step !== undefined ? cfg.step : (p.widgetType === 'INT' ? 1 : 0.01); right.appendChild(input);
      } else {
        input = document.createElement('input'); input.type = 'text'; input.className = 'w10-input'; input.value = val !== undefined ? String(val) : ''; right.appendChild(input);
      }
      input.dataset.comfyParam = paramName; input.dataset.comfyGroup = key; input.dataset.comfyNodeId = key; input.dataset.comfyWidgetIndex = String(j);
      if (p.isConnected) { input.disabled = true; input.title = '该参数由工作流连接提供'; }
      row.appendChild(right); details.appendChild(row);
    }
    card.appendChild(details); paramsEl.appendChild(card);
  }
  _bindComfyImageEvents(container); _bindComfyGroupToggles(container); _bindComfyNodeOrder(container); _bindComfyValueEvents(container);
}

// ========== \u540E\u7AEF\u6D88\u606F\u5904\u7406 ==========

function _handleHostMessage(action, data) {
  var container = _activeContainer;

  if (action === 'comfyCaptureImageResult') {
    var captureParam = TileAPI.state.get('comfyui.captureParam');
    if (data && data.success && captureParam) {
      var previews = TileAPI.state.get('comfyui.imagePreviews') || {};
      previews[captureParam] = data.base64;
      TileAPI.state.set('comfyui.imagePreviews', previews);
      if (container) {
        _renderComfyTopImageButtons(container);
        _renderComfyParams(container, TileAPI.state.get('comfyui.currentNodes') || []);
      }
      TileAPI.toast('图像已加载，可在预览中确认', 'success');
    } else if (data && !data.success) {
      TileAPI.toast('加载图像失败: ' + (data.error || '未知错误'), 'error');
    }
    return;
  }

  // --- \u8FDE\u63A5\u7ED3\u679C ---
  if (action === 'comfyConnectResult') {
    _comfyConnecting = false;
    var statusEl = container ? container.querySelector('#comfyStatus') : null;
    if (data && data.success) {
      if (statusEl) { statusEl.textContent = '\u2705 \u5DF2\u8FDE\u63A5'; statusEl.style.color = 'var(--accent)'; }
      TileAPI.state.set('comfyui.connected', true);
      // \u81EA\u52A8\u62C9\u53D6\u5DE5\u4F5C\u6D41
      TileAPI.sendToHost('comfyFetchWorkflows', { url: _getUrl() });
    } else {
      if (statusEl) { statusEl.textContent = '\u274C \u5931\u8D25: ' + (data ? data.error : ''); statusEl.style.color = '#ff6b6b'; }
      TileAPI.state.set('comfyui.connected', false);
      TileAPI.toast('ComfyUI \u8FDE\u63A5\u5931\u8D25: ' + (data ? data.error : ''), 'error');
    }
  }

  // --- \u5DE5\u4F5C\u6D41\u5217\u8868 ---
  if (action === 'comfyWorkflowsResult') {
    if (data && data.success) {
      var workflows = data.workflows || [];
      TileAPI.state.set('comfyui.workflows', workflows);
      if (container) {
        var sel = container.querySelector('#comfyWorkflowSelect');
        if (sel) {
          sel.innerHTML = '<option value="">-- \u5DE5\u4F5C\u6D41 (' + workflows.length + ') --</option>';
          for (var wi = 0; wi < workflows.length; wi++) {
            var wf = workflows[wi];
            var opt = document.createElement('option');
            opt.value = (wf && (wf.path || wf.name)) || wf;
            opt.textContent = (wf && (wf.name || wf.path)) || wf;
            sel.appendChild(opt);
          }
          _ensureWorkflowSelect(container);
          // \u6062\u590D\u4E0A\u6B21\u9009\u62E9
          var pending = TileAPI.state.get('comfyui._pendingSelectWf') || TileAPI.storage.get('comfyui.lastWorkflow');
          if (pending) {
            var pendingText = String(pending);
            var pendingBase = pendingText.replace(/\.json$/i, '');
            var matchedValue = '';
            for (var poi = 0; poi < sel.options.length; poi++) {
              var optionValue = String(sel.options[poi].value || '');
              if (optionValue === pendingText || optionValue.replace(/\.json$/i, '') === pendingBase) {
                matchedValue = optionValue;
                break;
              }
            }
            if (matchedValue) {
              sel.value = matchedValue;
              TileAPI.state.set('comfyui._pendingSelectWf', null);
              // 恢复上次工作流时同步加载参数，避免只选中名称却仍显示空参数区。
              TileAPI.sendToHost('comfyLoadWorkflow', {
                url: _getUrl(),
                name: matchedValue,
                showAll: false,
                source: 'comfyTab'
              });
            }
          }
        }
      }
      TileAPI.log('[ComfyUI] \u5DF2\u62C9\u53D6 ' + workflows.length + ' \u4E2A\u5DE5\u4F5C\u6D41', 'info');
    }
  }

  // --- \u5DE5\u4F5C\u6D41\u5DF2\u52A0\u8F7D ---
  if (action === 'comfyWorkflowLoaded') {
    if (data && data.success) {
      TileAPI.state.set('comfyui.currentWorkflow', data.workflow);
      TileAPI.state.set('comfyui.currentWorkflowName', data.name || '');
      var loadedNodes = _normalizeComfyNodes(data.nodes || data.params || []);
      // 防止旧版本宿主返回的内部常量节点混入当前参数区。
      loadedNodes = loadedNodes.filter(function(node) {
        var text = String((node && (node.title || node.type || node.name)) || '').trim();
        return !/^(?:PrimitiveString|PrimitiveInt|PrimitiveFloat|PrimitiveBool|PrimitiveBoolean|PrimitiveNode|Reroute|Note)$/i.test(text);
      });
      TileAPI.state.set('comfyui.currentNodes', loadedNodes);
      if (container) {
        _renderComfyTopImageButtons(container);
        _renderComfyParams(container, loadedNodes);
      }
      TileAPI.toast('\u5DE5\u4F5C\u6D41\u5DF2\u52A0\u8F7D: ' + (data.name || ''), 'success');

      // \u5982\u679C\u662F\u5176\u4ED6\u78C1\u8D34\u53D1\u8D77\u7684\u52A0\u8F7D\uFF0C\u5206\u53D1\u7ED9\u6865\u63A5\u51FD\u6570
      if (data.source !== 'comfyTab') {
        if (window._bp_selectComfyUIPreset) {
          window._bp_selectComfyUIPreset(data.name, loadedNodes, data.workflow);
        }
      }
    } else {
      TileAPI.toast('\u5DE5\u4F5C\u6D41\u52A0\u8F7D\u5931\u8D25: ' + (data ? data.error : ''), 'error');
    }
  }

  // --- \u8FDB\u5EA6 ---
  if (action === 'comfyProgress') {
    var progressTaskId = TileAPI.state.get('comfyui.currentTaskId');
    if (!data || !progressTaskId || String(data.taskId || '') !== String(progressTaskId)) return;
    if (container) {
      var pct = 0;
      if (data.progress !== undefined) {
        pct = Math.round((data.progress || 0) * 100);
      } else if (data.elapsed !== undefined && data.maxWait > 0) {
        pct = Math.min(99, Math.round((data.elapsed / data.maxWait) * 100));
      }
      var bar = container.querySelector('#comfyProgressBar');
      var text = container.querySelector('#comfyProgressText');
      if (bar) bar.style.width = pct + '%';
      if (text) text.textContent = pct + '% (' + (data.elapsed || 0) + 's)';
      var genBtn = container.querySelector('#comfyGenerateBtn');
      if (genBtn && TileAPI.state.get('comfyui.running')) {
        genBtn.textContent = '\u25A0 ' + pct + '% \u4E2D\u65AD';
      }
    }
  }

  // --- \u751F\u6210\u7ED3\u679C ---
  if (action === 'comfyGenerateResult') {
    var currentTaskId = TileAPI.state.get('comfyui.currentTaskId');
    if (!data || !currentTaskId || String(data.taskId || '') !== String(currentTaskId)) return;
    TileAPI.state.set('comfyui.running', false);
    if (container) _updateRunningUI(container, false);
    // 统一任务池由 Host 的 taskComplete 交给 tasks-service 收口，避免绕过账单/统计。
    TileAPI.state.set('comfyui.currentTaskId', null);
    if (data && data.success) {
      if (Array.isArray(data.results) && data.results.length) {
        TileAPI.state.set('comfyui.lastResultTaskId', data.taskId || '');
        TileAPI.state.set('comfyui.results', data.results);
        TileAPI.state.set('comfyui.resultIndex', 0);
        if (container) { _ensureGallery(container); _renderGallery(container); }
      }
      TileAPI.toast('ComfyUI \u751F\u6210\u5B8C\u6210!', 'success');
    } else {
      var errMsg = (data && data.error) ? data.error : '\u672A\u77E5\u9519\u8BEF';
      if (errMsg !== '\u5DF2\u4E2D\u65AD') {
        TileAPI.toast('ComfyUI \u751F\u6210\u5931\u8D25: ' + errMsg, 'error');
      }
    }
  }

  if (action === 'comfyReturnResultsResult') {
    if (data && data.success) {
      var returned = data.indexes || [];
      var currentResults = _galleryItems();
      for (var ri = 0; ri < returned.length; ri++) {
        for (var rj = 0; rj < currentResults.length; rj++) if (Number(currentResults[rj].index) === Number(returned[ri])) currentResults[rj].returned = true;
      }
      TileAPI.state.set('comfyui.results', currentResults);
      if (container) _renderGallery(container);
      TileAPI.toast('结果已发送到 Photoshop', 'success');
    } else if (data && data.error) TileAPI.toast('发送结果失败: ' + data.error, 'error');
    return;
  }

  if (action === 'comfySaveResultsResult') {
    if (data && data.success) TileAPI.toast('已保存 ' + (data.count || 0) + ' 张结果到 ComfyUI 导出文件夹', 'success');
    else if (data && data.error) TileAPI.toast('保存结果失败: ' + data.error, 'error');
    return;
  }

  // --- \u9519\u8BEF ---
  if (action === 'comfyError') {
    TileAPI.state.set('comfyui.running', false);
    if (container) _updateRunningUI(container, false);
    // taskComplete 会负责移除任务卡并记账。
    var errTid = (data && data.taskId) || TileAPI.state.get('comfyui.currentTaskId');
    if (errTid) {
      TileAPI.state.set('comfyui.currentTaskId', null);
    }
    TileAPI.toast('ComfyUI \u9519\u8BEF: ' + (data ? data.error : ''), 'error');
  }
}

// ========== \u6865\u63A5\u51FD\u6570 ==========

window._bp_getComfyWorkflows = function() {
  var workflows = TileAPI.state.get('comfyui.workflows') || [];
  return workflows.map(function(wf) {
    var name = wf.name || wf;
    var catId = 'other';
    var displayName = name;

    var baseName = name;
    if (baseName.indexOf('/') !== -1) baseName = baseName.split('/').pop();
    else if (baseName.indexOf('\\') !== -1) baseName = baseName.split('\\').pop();

    var match = baseName.match(/^@37_([^_]+)_(.+)$/);
    if (match) {
      var folderName = match[1].trim();
      displayName = match[2].trim();
      if (/\u9762\u90E8|\u8138|\u5934|\u773C|\u5507|\u9F3B|\u7709/.test(folderName)) catId = 'head';
      else if (/\u53D1|\u6BDB\u53D1/.test(folderName)) catId = 'hair';
      else if (/\u80F8|\u8EAF\u5E72|\u8170|\u8179|\u8EAB\u4F53/.test(folderName)) catId = 'torso';
      else if (/\u624B\u81C2/.test(folderName)) catId = 'arms';
      else if (/\u624B/.test(folderName)) catId = 'hands';
      else if (/\u817F|\u4E1D\u889C|\u7F51\u889C/.test(folderName)) catId = 'legs';
      else if (/\u811A/.test(folderName)) catId = 'feet';
      else if (/\u670D\u88C5|\u8863\u670D|\u88D9/.test(folderName)) catId = 'clothing';
      else if (/\u80CC\u666F|\u573A\u666F/.test(folderName)) catId = 'background';
      else if (/\u5149\u5F71|\u5149\u6655|\u706F\u5149|\u9713\u8679/.test(folderName)) catId = 'lighting';
      else if (/\u7279\u6548|\u7C98\u6DB2|\u6C34\u6D41|\u706B\u7130|\u51B0\u971C|\u96F7\u7535/.test(folderName)) catId = 'effects';
      else if (/\u914D\u9970|\u9053\u5177|\u9996\u9970/.test(folderName)) catId = 'accessory';
      else if (/\u53BB\u6742\u7269|\u4FEE\u8865|\u53BB\u6C34\u5370|\u6E05\u7406/.test(folderName)) catId = 'cleanup';
      else if (/\u5168\u8EAB/.test(folderName)) catId = 'fullbody';
      else if (/\u6B66\u5668/.test(folderName)) catId = 'weapon';
      else if (/\u9888\u90E8/.test(folderName)) catId = 'neck';
    } else {
      displayName = baseName;
    }

    return {
      name: name,
      displayName: displayName,
      category: catId,
      data: wf
    };
  });
};

window._bp_loadComfyUIWorkflow = function(wfName) {
  TileAPI.sendToHost('comfyLoadWorkflow', { url: _getUrl(), name: wfName, showAll: false });
  TileAPI.log('[ComfyUI] \u6B63\u5728\u8BF7\u6C42\u5DE5\u4F5C\u6D41\u53C2\u6570: ' + wfName, 'info');
};

})();
