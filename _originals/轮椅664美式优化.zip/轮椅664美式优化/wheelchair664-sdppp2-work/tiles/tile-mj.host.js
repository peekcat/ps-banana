// ============================================================
//  tile-mj.host.js
//  MJ 磁贴的后端处理器。
//
//  为什么需要这个文件:
//    tiles/tile-mj.js 跑在 index.html 的 <webview>(panel.html) 里,
//    那是个沙箱浏览器环境, 没有 require('uxp'), 拿不到文件选择器。
//    原来在前端直接 require('uxp') 必然抛异常, 被 catch 吞掉后
//    只弹一句"文件选择不可用" —— 这就是上传按钮点了没反应的原因。
//    文件选择必须放在 host 侧(本文件), 读完再把 base64 回传给面板。
// ============================================================

var HostAPI = require('../host/host-api.js');
var uxpModule = require('uxp');
var storage = uxpModule.storage;
var fs = storage.localFileSystem;

var MAX_REFS = 4;

// 二进制 ArrayBuffer → base64。分块转换, 避免超大图 apply 时爆栈。
function _bufToBase64(buf) {
    var bytes = new Uint8Array(buf);
    var binary = '';
    for (var i = 0; i < bytes.length; i += 8192) {
        binary += String.fromCharCode.apply(null, bytes.subarray(i, i + 8192));
    }
    return btoa(binary);
}

// ── uploadRefImages —— 弹系统文件选择器, 读图回传面板 ──
HostAPI.registerAction('uploadRefImages', async function(data, ctx) {
    // 面板告诉我们还能再放几张, 缺省按满额算
    var room = Math.max(0, Math.min(MAX_REFS, (data && typeof data.room === 'number') ? data.room : MAX_REFS));
    if (room <= 0) {
        ctx.sendToPanel('uploadRefImagesResult', { success: false, error: '最多 ' + MAX_REFS + ' 张参考图' });
        return;
    }

    var files;
    try {
        files = await fs.getFileForOpening({
            types: ['jpg', 'jpeg', 'png', 'gif', 'webp'],
            allowMultiple: true
        });
    } catch (e) {
        ctx.sendToPanel('uploadRefImagesResult', { success: false, error: '打开文件选择器失败: ' + ((e && e.message) || e) });
        return;
    }

    // 用户点了取消 → 静默收场, 不当成错误弹红条
    if (!files || (Array.isArray(files) && files.length === 0)) {
        ctx.sendToPanel('uploadRefImagesResult', { success: false, cancelled: true });
        return;
    }
    if (!Array.isArray(files)) files = [files];

    var picked = files.slice(0, room);
    var images = [];
    var failed = 0;
    for (var i = 0; i < picked.length; i++) {
        try {
            var buf = await picked[i].read({ format: storage.formats.binary });
            images.push(_bufToBase64(buf));
        } catch (e) {
            failed++;
            console.warn('[MJ 参考图] 读取失败 ' + picked[i].name + ': ' + ((e && e.message) || e));
        }
    }

    if (!images.length) {
        ctx.sendToPanel('uploadRefImagesResult', { success: false, error: '图片读取失败' });
        return;
    }

    ctx.sendToPanel('uploadRefImagesResult', {
        success: true,
        images: images,
        skipped: files.length - picked.length,   // 超出 4 张上限被丢掉的
        failed: failed
    });
}, { tileId: 'mj' });

module.exports = {};
