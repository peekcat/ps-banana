(function() {
'use strict';

var MJ_RATIOS = [
  { value: 'Auto', label: '自动按选区' },
  { value: '1:1', label: '1:1' },
  { value: '16:9', label: '16:9' },
  { value: '9:16', label: '9:16' },
  { value: '3:2', label: '3:2' },
  { value: '2:3', label: '2:3' },
  { value: '4:3', label: '4:3' },
  { value: '3:4', label: '3:4' }
];

function _refs() { return TileAPI.state.get('mj.refs') || []; }
// PS 抓取是异步操作，避免 MJ 磁贴重复排队同一张参考图。
var _mjCaptureInFlight = false;
function _setRefs(list) {
  TileAPI.state.set('mj.refs', list || []);
  TileAPI.storage.set('mj.refs', list || []);
  TileAPI.emit('mj:refsUpdated');
}
function _useRefs() {
  var v = TileAPI.state.get('mj.useRefs');
  return v === undefined || v === null ? false : !!v;
}
function _mode() { return TileAPI.state.get('mj.mode') || 'fast'; }
function _hd() { return !!TileAPI.state.get('mj.hd'); }
function _ratio() { return TileAPI.state.get('mj.aspectRatio') || 'Auto'; }
function _esc(v) {
  return String(v == null ? '' : v).replace(/[&<>"']/g, function(c) {
    return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
  });
}
function _conn() {
  return typeof window._settingsGetActiveConnection === 'function'
    ? (window._settingsGetActiveConnection('momo') || {})
    : { provider: 'momo', url: '', key: '' };
}
function _ratioOptions() {
  var cur = _ratio();
  return MJ_RATIOS.map(function(item) {
    return '<option value="' + item.value + '"' + (item.value === cur ? ' selected' : '') + '>' + item.label + '</option>';
  }).join('');
}

function _renderRefTile(refs) {
  var html = '<div class="mj-ref-tile">' +
    '<div class="mj-ref-toolbar"><span class="mj-ref-title">参考图</span><span class="mj-ref-count">' + refs.length + '/4</span>' +
    '<button class="w10-btn" id="mjCaptureRef" title="从 Photoshop 选区抓取">＋ PS</button>' +
    '<button class="w10-btn" id="mjUploadRef" title="从电脑上传图片">📁 上传</button></div>';
  if (!refs.length) html += '<div class="mj-ref-empty">暂无参考图</div>';
  else {
    html += '<div class="mj-ref-grid">';
    refs.forEach(function(b64, i) {
      html += '<div class="mj-ref-thumb"><img src="data:image/png;base64,' + b64 + '"><button data-mj-ref-del="' + i + '" title="删除">×</button></div>';
    });
    html += '</div>';
  }
  return html + '</div>';
}

function renderFront(container, w) {
  var count = _refs().length;
  container.innerHTML = '<div class="tile-icon">MJ</div><div class="tile-label">MJ</div>' +
    (w >= 2 ? '<div class="tile-desc">' + (_useRefs() ? ('参考图 ' + count + '/4') : '文生图') + '</div>' : '');
}

function _renderPanel(container) {
  var refs = _refs();
  var conn = _conn();
  var keyReady = !!conn.key;
  var html = '<div class="w10-panel mj-panel">' +
    '<div class="mj-titlebar"><div><div class="mj-title">MJ 生成</div><div class="mj-subtitle">Midjourney · 墨墨渠道</div></div><div class="mj-notice">请务必安装酸奶老师提供的skill于codex软件内，并结合codex软件使用</div><span class="mj-status-dot ' + (keyReady ? 'is-ready' : '') + '"></span></div>' +
    '<div class="forge-group" data-forge-group="提示词"><div class="w10-section-title forge-group-head"><span class="forge-group-arrow">▾</span>提示词</div><div class="forge-group-body">' +
      '<textarea id="mjPrompt" class="forge-textarea" rows="4" placeholder="Describe the image in English"></textarea></div></div>' +
    '<div class="forge-group" data-forge-group="参考图"><div class="w10-section-title forge-group-head"><span class="forge-group-arrow">▾</span>参考图</div><div class="forge-group-body"><div class="mj-reference-strip">' +
      '<button class="w10-btn' + (_useRefs() ? ' w10-btn-accent' : '') + '" id="mjUseRefs">' + (_useRefs() ? '已启用' : '启用参考图') + '</button><span class="mj-ref-count">仅使用 MJ 内置参考图 · ' + refs.length + '/4</span>' +
      '</div>' + _renderRefTile(refs) + '</div></div>' +
    '<div class="forge-group" data-forge-group="参数"><div class="w10-section-title forge-group-head"><span class="forge-group-arrow">▾</span>参数</div><div class="forge-group-body"><div class="w10-row"><div class="w10-row-left"><div class="w10-row-label">比例</div></div>' +
      '<div class="w10-row-right"><select class="w10-select" id="mjAspect">' + _ratioOptions() + '</select></div></div>' +
    '<div class="w10-row"><div class="w10-row-left"><div class="w10-row-label">模式</div></div><div class="w10-row-right"><div class="anti-btns-row">' +
      '<button class="w10-btn' + (_mode() === 'fast' ? ' w10-btn-accent' : '') + '" data-mj-mode="fast">快速</button>' +
      '<button class="w10-btn' + (_mode() === 'relax' ? ' w10-btn-accent' : '') + '" data-mj-mode="relax">慢速</button>' +
      '<button class="w10-btn' + (_hd() ? ' w10-btn-accent' : '') + '" id="mjHd">高清</button>' +
    '</div></div></div>' +
    '<div class="w10-section-title">连接</div><div class="w10-row"><div class="w10-row-left"><div class="w10-row-label">墨墨 Key</div></div><div class="w10-row-right"><span style="color:' + (keyReady ? 'var(--accent)' : 'var(--text-sub)') + '">' + (keyReady ? '已配置' : '未配置') + '</span></div></div>' +
    '<div class="mj-action-bar"><button class="w10-btn w10-btn-accent mj-generate-btn" id="mjGenerate">▶ 生成</button></div>' +
    '</div>';
  container.innerHTML = html;

  var groupHeads = container.querySelectorAll('[data-forge-group-head], .forge-group-head');
  for (var gh = 0; gh < groupHeads.length; gh++) {
    groupHeads[gh].addEventListener('click', function() {
      var group = this.closest('.forge-group');
      if (group) group.classList.toggle('is-collapsed');
    });
  }

  var prompt = TileAPI.storage.get('mj.prompt') || '';
  var ta = container.querySelector('#mjPrompt');
  if (ta) { ta.value = prompt; ta.addEventListener('input', function() { TileAPI.storage.set('mj.prompt', ta.value); }); }
  var toggle = container.querySelector('#mjUseRefs');
  if (toggle) toggle.addEventListener('click', function() { var next = !_useRefs(); TileAPI.state.set('mj.useRefs', next); TileAPI.storage.set('mj.useRefs', next); _renderPanel(container); });
  var cap = container.querySelector('#mjCaptureRef');
  if (cap) {
    _setMjCaptureBusy(cap, _mjCaptureInFlight);
    cap.addEventListener('click', function() {
    if (_mjCaptureInFlight) return;
    if (_refs().length >= 4) { TileAPI.toast('最多 4 张参考图', 'error'); return; }
    _mjCaptureInFlight = true;
    _setMjCaptureBusy(cap, true);
    try {
      TileAPI.sendToHost('captureRefImage');
    } catch (e) {
      _mjCaptureInFlight = false;
      _setMjCaptureBusy(cap, false);
      TileAPI.toast('发送捕获请求失败: ' + (e.message || e), 'error');
      return;
    }
    TileAPI.toast('正在从 Photoshop 抓取参考图...', 'info');
    });
  }
  var upload = container.querySelector('#mjUploadRef');
  if (upload) upload.addEventListener('click', function() { _uploadRefFiles(); });
  var delBtns = container.querySelectorAll('[data-mj-ref-del]');
  for (var di = 0; di < delBtns.length; di++) delBtns[di].addEventListener('click', function() {
    var next = _refs().slice(); next.splice(+this.getAttribute('data-mj-ref-del'), 1); _setRefs(next); _renderPanel(container);
  });
  var aspect = container.querySelector('#mjAspect');
  if (aspect) aspect.addEventListener('change', function() { TileAPI.state.set('mj.aspectRatio', aspect.value); TileAPI.storage.set('mj.aspectRatio', aspect.value); });
  var modes = container.querySelectorAll('[data-mj-mode]');
  for (var i = 0; i < modes.length; i++) modes[i].addEventListener('click', function() {
    var value = this.getAttribute('data-mj-mode');
    TileAPI.state.set('mj.mode', value); TileAPI.storage.set('mj.mode', value);
    for (var j = 0; j < modes.length; j++) modes[j].classList.toggle('w10-btn-accent', modes[j].getAttribute('data-mj-mode') === value);
  });
  var hd = container.querySelector('#mjHd');
  if (hd) hd.addEventListener('click', function() { var next = !_hd(); TileAPI.state.set('mj.hd', next); TileAPI.storage.set('mj.hd', next); hd.classList.toggle('w10-btn-accent', next); });
  var gen = container.querySelector('#mjGenerate');
  if (gen) gen.addEventListener('click', function() { _generate(container); });
}

function _setMjCaptureBusy(btn, busy) {
  if (!btn) return;
  btn.disabled = !!busy;
  btn.setAttribute('aria-busy', busy ? 'true' : 'false');
  btn.style.opacity = busy ? '0.55' : '';
  btn.style.cursor = busy ? 'wait' : '';
}

// 文件选择只能在 host 侧做。
// 本文件跑在 index.html 的 <webview>(panel.html) 沙箱里 —— 那是个浏览器环境,
// 压根没有 require, 所以 require('uxp') 必然抛异常, storage 恒为 null,
// 上一版就是卡在这一步弹'文件选择不可用', 选择框从来没机会弹出来。
// (上一版猜是 allowMultiple 的锅并加了单选回退, 但那段代码根本执行不到。)
// 正确做法: 发消息给 tiles/tile-mj.host.js, 在真正的 UXP 宿主里弹选择器,
// 读成 base64 再回传, 结果走下面的 onMessage。＋PS 按钮一直能用就是这个路子。
function _uploadRefFiles() {
  var room = 4 - _refs().length;
  if (room <= 0) { TileAPI.toast('最多 4 张参考图', 'error'); return; }
  TileAPI.sendToHost('uploadRefImages', { room: room });
}

function _generate(container) {
  var ta = container.querySelector('#mjPrompt');
  var prompt = ta ? ta.value.trim() : '';
  if (!prompt) { TileAPI.toast('请先输入 MJ 提示词', 'error'); return; }
  var conn = _conn();
  if (!conn.key) { TileAPI.toast('请先在设置中配置墨墨 API Key', 'error'); return; }
  if (!conn.url) { TileAPI.toast('请先在设置中配置墨墨 API URL', 'error'); return; }
  var refs = _useRefs() ? _refs() : [];
  var taskId = 'mj_' + Date.now() + '_' + Math.random().toString(36).slice(2, 7);
  TileAPI.sendToHost('runSingle', {
    taskId: taskId, engine: 'api', batchSize: 1, timeout: 3600,
    apiKey: conn.key, apiBaseUrl: conn.url, prompt: prompt, size: '1K',
    model: 'mj_imagine', provider: 'momo', aspectRatio: _ratio(),
    refImages: refs, mjMode: _mode(), mjHd: _hd(), autoReturn: true,
    presetTitle: 'MJ'
  });
  TileAPI.toast('MJ 任务已提交', 'success');
}

TileAPI.registerTile({
  id: 'mj', group: 'main', icon: '🎨', iconImage: 'icons/mjlogo.svg', label: 'MJ', desc: 'Midjourney 独立生成', live: true,
  defaultSize: { w: 2, h: 2 }, minSize: { w: 1, h: 1 }, maxSize: { w: 4, h: 8 },
  renderFront: renderFront,
  renderBack: function(container) { container.textContent = _useRefs() ? ('MJ 参考图 · ' + _refs().length + '/4') : 'MJ 文生图'; },
  onMessage: function(action, data) {
    if (action === 'captureRefResult') {
      _mjCaptureInFlight = false;
      var capBtn = document.getElementById('mjCaptureRef');
      _setMjCaptureBusy(capBtn, false);
      if (!data || !data.base64) {
        if (data && data.error) TileAPI.toast(data.error, 'error');
        return;
      }
      if (_refs().length >= 4) return;
      _setRefs(_refs().concat([data.base64]));
      TileAPI.toast('参考图已加入 MJ', 'success');
      return;
    }
    if (action === 'uploadRefImagesResult' && data) {
      if (!data.success) {
        // 用户自己点的取消, 不用弹红条打扰
        if (!data.cancelled) TileAPI.toast('参考图上传失败: ' + (data.error || '未知错误'), 'error');
        return;
      }
      var before = _refs().length;
      _setRefs(_refs().concat(data.images || []).slice(0, 4));
      var added = _refs().length - before;
      if (!added) { TileAPI.toast('最多 4 张参考图', 'error'); return; }
      var msg = added + ' 张参考图已加入 MJ';
      if (data.skipped) msg += '(超出 4 张上限, 已忽略 ' + data.skipped + ' 张)';
      if (data.failed) msg += '(' + data.failed + ' 张读取失败)';
      TileAPI.toast(msg, 'success');
    }
  },
  onExpand: function(container) {
    if (!TileAPI.state.get('mj.refs')) TileAPI.state.set('mj.refs', TileAPI.storage.get('mj.refs') || []);
    _renderPanel(container);
    var sub = function() { _renderPanel(container); };
    TileAPI.on('mj:refsUpdated', sub);
    TileAPI.on('settings:updated', sub);
    return function() { TileAPI.off('mj:refsUpdated', sub); TileAPI.off('settings:updated', sub); };
  },
  onResize: renderFront
});

})();
